// Reports where the RustDesk remote window is, for rustdesk-display-client.py.
// GNOME on Wayland doesn't expose window positions to other programs; an extension can.
//   gdbus call --session --dest org.gnome.Shell --object-path /org/sb4edge/RustDeskWindow \
//     --method org.sb4edge.RustDeskWindow.Get 516860502
import Gio from 'gi://Gio';
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

const IFACE = `<node>
  <interface name="org.sb4edge.RustDeskWindow">
    <method name="Get">
      <arg type="s" direction="in" name="match"/>
      <arg type="s" direction="out" name="title"/>
      <arg type="i" direction="out" name="x"/>
      <arg type="i" direction="out" name="y"/>
      <arg type="i" direction="out" name="width"/>
      <arg type="i" direction="out" name="height"/>
    </method>
  </interface>
</node>`;

export default class RustDeskWindowExtension extends Extension {
    enable() {
        this._dbus = Gio.DBusExportedObject.wrapJSObject(IFACE, this);
        this._dbus.export(Gio.DBus.session, '/org/sb4edge/RustDeskWindow');
    }

    disable() {
        this._dbus?.unexport();
        this._dbus = null;
    }

    // The remote session window (title contains the remote's ID, else "Remote Desktop"),
    // preferring the focused one. Frame rect is in logical (layout) coordinates.
    Get(match) {
        const windows = global.get_window_actors()
            .map(a => a.meta_window)
            .filter(w => (w.get_wm_class() || '').toLowerCase().includes('rustdesk') && !w.minimized);
        let candidates = windows.filter(w => match && (w.get_title() || '').includes(match));
        if (!candidates.length)
            candidates = windows.filter(w => (w.get_title() || '').includes('Remote Desktop'));
        if (!candidates.length)
            return ['', 0, 0, 0, 0];
        const win = candidates.find(w => w.has_focus()) || candidates[0];
        const r = win.get_frame_rect();
        return [win.get_title(), r.x, r.y, r.width, r.height];
    }
}
