/**
 * This file is part of Hide Top Bar (Multi-Monitor)
 *
 * Fork of Hide Top Bar by Thomas Vogt, extended for multi-monitor support.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import * as PanelVisibilityManager from './panelVisibilityManager.js';
import * as SecondaryPanel from './secondaryPanel.js';
import * as Convenience from './convenience.js';

const DEBUG = Convenience.DEBUG;
const MMDEBUG = Convenience.MMDEBUG;

/**
 * MultiMonitorManager orchestrates one visibility controller per monitor.
 *
 * Current scope:
 *   - Classic mode (multi-monitor-enabled = false): a single primary
 *     controller reproduces the original single-monitor Hide Top Bar
 *     behaviour. This is the default and is fully implemented.
 *   - Multi-monitor mode (multi-monitor-enabled = true): secondary panels and
 *     per-monitor controllers are introduced in a later phase. For now the
 *     manager recognises the setting, reacts to it dynamically, and keeps the
 *     primary controller intact; secondary panels are not created yet.
 *
 * The class is intentionally the single owner of controller lifetimes so that
 * disable() tears everything down and restores the shell to its original
 * state.
 */
// Position, size and scale of a monitor: a secondary panel built for it is reused while these stay the same.
function geometryKey(m) {
	return `${m.x},${m.y},${m.width},${m.height},${m.geometry_scale}`;
}

export class MultiMonitorManager {
	constructor(settings, uuid) {
		DEBUG("MultiMonitorManager()");
		MMDEBUG("manager.enable: _startingUp=" + Main.layoutManager._startingUp
			+ " monitors=" + Main.layoutManager.monitors.length
			+ " primaryIndex=" + Main.layoutManager.primaryIndex
			+ " mmEnabled=" + settings.get_boolean('multi-monitor-enabled'));
		this._settings = settings;
		// Owning extension's UUID, injected so helpers that need it (e.g. the
		// Desktop Icons NG integration) do not have to resolve it via
		// Extension.lookupByURL().
		this._uuid = uuid;

		// The primary controller manages the shell's own panelBox and all the
		// shell-global resources (banner patch, overview search padding, hot
		// corner, keybinding). It exists in both classic and multi-monitor
		// modes.
		this._primaryController = null;

		// Secondary panel boxes, keyed by monitor index. Indices are only used
		// as transient keys within a single monitor configuration; the map is
		// rebuilt from scratch whenever the monitor set changes, so no index is
		// assumed to be stable across monitors-changed.
		this._secondaryPanels = new Map();

		// Signal handler owned by the manager for its own settings listeners.
		this._signalsHandler = new Convenience.GlobalSignalsHandler();

		// Guards against overlapping rebuilds (e.g. a monitors-changed firing
		// while a rebuild is already running).
		this._rebuilding = false;

		this._multiMonitorEnabled = this._settings.get_boolean(
			'multi-monitor-enabled'
		);

		// Build the primary once with the strategy matching the current mode
		// (classic -> 'overlap', MM -> shared hide-mode). Then wire the
		// mode-specific listeners and secondary panels without rebuilding the
		// primary again at startup.
		this._buildPrimaryController();
		this._applyMultiMonitorMode({ rebuildPrimary: false });

		// React to runtime changes of the multi-monitor master switch.
		this._signalsHandler.add([
			this._settings,
			'changed::multi-monitor-enabled',
			this._onMultiMonitorEnabledChanged.bind(this),
		]);
	}

	/**
	 * Strategy to apply to the PRIMARY panel. When multi-monitor mode is off we
	 * must preserve the classic behaviour strictly, so the primary always uses
	 * the original 'overlap' intellihide. Only when multi-monitor mode is on
	 * does the shared hide-mode setting apply to the primary too.
	 */
	_primaryHideStrategy() {
		if (!this._multiMonitorEnabled)
			return 'overlap';
		return this._settings.get_string('multi-monitor-hide-mode');
	}

	_buildPrimaryController() {
		const primaryIndex = Main.layoutManager.primaryIndex;
		this._primaryController = new PanelVisibilityManager.PanelVisibilityManager(
			this._settings,
			primaryIndex,
			{
				panelBox: Main.layoutManager.panelBox,
				isPrimary: true,
				hideStrategy: this._primaryHideStrategy(),
				uuid: this._uuid,
			}
		);
	}

	_rebuildPrimaryController() {
		this._destroyPrimaryController();
		this._buildPrimaryController();
	}

	_destroyPrimaryController() {
		if (this._primaryController) {
			this._primaryController.destroy();
			this._primaryController = null;
		}
	}

	_onMultiMonitorEnabledChanged() {
		const enabled = this._settings.get_boolean('multi-monitor-enabled');
		if (enabled === this._multiMonitorEnabled)
			return;
		this._multiMonitorEnabled = enabled;
		DEBUG("multi-monitor-enabled changed to " + enabled);
		this._applyMultiMonitorMode({ rebuildPrimary: true });
	}

	/**
	 * Apply the current multi-monitor mode. In classic mode only the primary
	 * controller exists. In multi-monitor mode a visible secondary panel is
	 * created on every non-primary monitor, and a monitors-changed listener
	 * keeps them in sync. This is the single place that owns that transition,
	 * so the master switch can be toggled at runtime without restarting the
	 * shell.
	 */
	_applyMultiMonitorMode(opts = {}) {
		const rebuildPrimary = opts.rebuildPrimary ?? true;
		if (this._multiMonitorEnabled) {
			DEBUG("multi-monitor mode ON");
			// Rebuild secondary panels whenever the monitor set changes
			// (connect/disconnect/reorder, primary change, resolution/scale).
			// Rebuild the primary when the shared hide-mode changes, since its
			// strategy is fixed at construction time.
			this._signalsHandler.addWithLabel("multimonitor",
				[
					Main.layoutManager,
					'monitors-changed',
					this._onMonitorsChanged.bind(this),
				],
				[
					// When the extension is loaded during session startup,
					// monitor coordinates are still transformed by the startup
					// animation, so _rebuildSecondaryPanels() bails out via the
					// _startingUp guard. This signal fires once the animation
					// finishes and geometry is final, letting us build the
					// panels then. Nothing else re-triggers that build, which is
					// why panels were missing until a manual toggle.
					Main.layoutManager,
					'startup-complete',
					this._onStartupComplete.bind(this),
				],
				[
					this._settings,
					'changed::multi-monitor-hide-mode',
					this._onHideModeChanged.bind(this),
				],
				[
					// Overview coordination for the SECONDARY panels only. The
					// primary panel keeps its own overview handling inside
					// PanelVisibilityManager; this must not touch it. A single
					// pair of listeners drives all secondary panels, so there is
					// never one connection per monitor.
					Main.overview,
					'showing',
					this._onOverviewShowing.bind(this),
				],
				[
					Main.overview,
					'hiding',
					this._onOverviewHiding.bind(this),
				]
			);
			// Apply the shared hide-mode to the primary too (only when the
			// mode actually changed; skipped at startup to avoid a redundant
			// rebuild of the shell-global primary resources).
			if (rebuildPrimary)
				this._rebuildPrimaryController();
			this._rebuildSecondaryPanels();
		} else {
			DEBUG("classic mode (primary monitor only)");
			this._signalsHandler.disconnectWithLabel("multimonitor");
			this._destroySecondaryPanels();
			// Restore the strict classic primary (always 'overlap').
			if (rebuildPrimary)
				this._rebuildPrimaryController();
		}
	}

	_onHideModeChanged() {
		if (!this._multiMonitorEnabled)
			return;
		DEBUG("multi-monitor-hide-mode changed; rebuilding primary");
		// Secondary controllers reconfigure themselves via their own listener;
		// only the primary needs an explicit rebuild.
		this._rebuildPrimaryController();
	}

	_onMonitorsChanged() {
		if (!this._multiMonitorEnabled)
			return;
		DEBUG("monitors-changed");
		this._rebuildPrimaryController();
		this._rebuildSecondaryPanels();
	}

	_overviewForcesVisible() {
		return this._settings.get_boolean('multi-monitor-overview');
	}

	/**
	 * Force all secondary panels visible (or release the force), honouring the
	 * multi-monitor-overview preference. When the preference is off we never
	 * force, so each monitor keeps its own strategy decision during overview.
	 */
	_setSecondariesForcedVisible(forced) {
		for (const panel of this._secondaryPanels.values())
			panel.setForcedVisible(forced);
	}

	_onOverviewShowing() {
		if (!this._multiMonitorEnabled)
			return;
		if (!this._overviewForcesVisible())
			return;
		MMDEBUG("overview showing: forcing secondary panels visible");
		this._setSecondariesForcedVisible(true);
	}

	_onOverviewHiding() {
		if (!this._multiMonitorEnabled)
			return;
		// Always release the force on hide, even if the preference was turned
		// off while the overview was open, so no panel is left stuck visible.
		MMDEBUG("overview hiding: releasing secondary panels");
		this._setSecondariesForcedVisible(false);
	}

	_onStartupComplete() {
		if (!this._multiMonitorEnabled)
			return;
		DEBUG("startup-complete");
		MMDEBUG("startup-complete received; rebuilding secondary panels");
		// Geometry is now final; build the panels that the startup guard
		// skipped. _rebuildSecondaryPanels() is idempotent (it tears down and
		// recreates), so this cannot produce duplicates even if some panels
		// already exist.
		this._rebuildSecondaryPanels();
	}

	/**
	 * Bring the secondary panels in line with the current monitor
	 * configuration: panels of monitors that are gone, became primary or
	 * changed geometry/scale are destroyed and rebuilt; the others are kept.
	 */
	_rebuildSecondaryPanels() {
		if (this._rebuilding)
			return;
		this._rebuilding = true;
		try {
			// sb4edge: keep a secondary panel whose monitor still has the same
			// geometry and scale. Every monitors-changed (several at login, at
			// resume, display reconfiguration) used to destroy and rebuild all of
			// them: GNOME's top bar items never disconnect from session-wide
			// objects, so each rebuild left work behind, and rebuilding the whole
			// panel is costly. Only changed or removed monitors are rebuilt.
			const startingUp = Main.layoutManager._startingUp;
			const primary = Main.layoutManager.primaryIndex;
			const current = Main.layoutManager.monitors;
			for (const [i, box] of [...this._secondaryPanels]) {
				const m = current[i];
				if (startingUp || i === primary || !m || box.geometryKey !== geometryKey(m)) {
					box.destroy();
					this._secondaryPanels.delete(i);
				}
			}

			// The startup animation temporarily transforms monitor
			// coordinates; skip until the shell is settled.
			if (startingUp) {
				MMDEBUG("_rebuildSecondaryPanels: skipped (_startingUp=true)");
				return;
			}

			const primaryIndex = Main.layoutManager.primaryIndex;
			const monitors = Main.layoutManager.monitors;
			MMDEBUG("_rebuildSecondaryPanels: enter, monitors=" + monitors.length
				+ " primaryIndex=" + primaryIndex);

			let created = 0;
			for (let i = 0; i < monitors.length; i++) {
				if (i === primaryIndex)
					continue;
				if (this._secondaryPanels.has(i))
					continue; // never duplicate a controller for a monitor
				const box = new SecondaryPanel.SecondaryPanelBox(
					i, monitors[i], this._settings
				);
				box.geometryKey = geometryKey(monitors[i]);
				this._secondaryPanels.set(i, box);
				created++;
			}
			MMDEBUG("_rebuildSecondaryPanels: exit, created=" + created
				+ " total=" + this._secondaryPanels.size);
		} finally {
			this._rebuilding = false;
		}
	}

	_destroySecondaryPanels() {
		for (const panel of this._secondaryPanels.values())
			panel.destroy();
		this._secondaryPanels.clear();
	}

	destroy() {
		DEBUG("MultiMonitorManager.destroy()");
		this._signalsHandler.destroy();
		this._signalsHandler = null;
		this._destroySecondaryPanels();
		this._destroyPrimaryController();
		this._settings = null;
	}
}
