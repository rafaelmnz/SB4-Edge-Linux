# Translations

Source translation files for Hide Top Bar (Multi-Monitor).

- `hidetopbar-multimonitor.pot` — translation template (all translatable
  strings from `Settings.ui` and `prefs.js`).
- `<lang>.po` — editable catalogues per language.
- Compiled `.mo` files live in
  `../locale/<lang>/LC_MESSAGES/hidetopbar-multimonitor@linuxitos.local.mo`
  and are what GNOME Shell actually loads at runtime.

The gettext domain is `hidetopbar-multimonitor@linuxitos.local`, matching
`gettext-domain` in `metadata.json`.

## Languages

- Base (source): English (the `msgid` strings; no `.po` needed).
- Fully translated: `es` (Spanish), `es_MX` (Mexican Spanish).
- Inherited from the original Hide Top Bar (original strings translated,
  multi-monitor strings still fall back to English): `ca`, `de`, `fr`,
  `it_IT`, `nl`, `pl`, `pt_BR`, `ru_RU`, `zh_CN`.

Translation credits are recorded in each `.po` header and in `../AUTHORS`.

## Regenerating the catalogues

From the extension directory (the one containing `metadata.json`):

```sh
# 1. Regenerate the template from the sources
xgettext --from-code=UTF-8 --language=Glade --keyword=translatable \
  -o po/ui.pot Settings.ui
xgettext --from-code=UTF-8 --language=JavaScript --keyword=_ --keyword=gettext \
  -o po/js.pot prefs.js
msgcat --use-first po/ui.pot po/js.pot -o po/hidetopbar-multimonitor.pot
rm -f po/ui.pot po/js.pot

# 2. Update each catalogue, keeping existing translations
for po in po/*.po; do
    msgmerge --update --backup=none "$po" po/hidetopbar-multimonitor.pot
done

# 3. Compile the catalogues GNOME loads at runtime
for po in po/*.po; do
    lang=$(basename "$po" .po)
    mkdir -p "locale/$lang/LC_MESSAGES"
    msgfmt "$po" \
      -o "locale/$lang/LC_MESSAGES/hidetopbar-multimonitor@linuxitos.local.mo"
done
```

## Adding a new language

```sh
msginit --input=po/hidetopbar-multimonitor.pot --locale=<lang> --output=po/<lang>.po
# then translate po/<lang>.po and run step 3 above
```
