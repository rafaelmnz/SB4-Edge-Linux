/**
 * This file is part of Hide Top Bar
 *
 * Copyright 2020 Thomas Vogt
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import Meta from 'gi://Meta';

export const DEBUG = function (message) {
	// Enable for debugging purposes.
	if (false) console.log(Date().substr(16, 8) + " [hidetopbar]: " + message);
}

// Multi-monitor diagnostic logging. Flip MM_DEBUG to false to silence it
// completely. Kept on during the startup-initialisation investigation so the
// journal shows exactly what happens at session login. Logs are low-volume
// (lifecycle events only), carry no sensitive data, and are prefixed [HTB-MM]
// so they can be filtered with: journalctl --user -o cat /usr/bin/gnome-shell | grep HTB-MM
export const MM_DEBUG_ENABLED = false;

export const MMDEBUG = function (message) {
	if (MM_DEBUG_ENABLED)
		console.log("[HTB-MM] " + message);
}

// try to simplify global signals handling
export class GlobalSignalsHandler {
	constructor() {
		this._signals = new Object();
	}

	add(/*unlimited 3-long array arguments*/) {
		this._addSignals('generic', arguments);
	}

	destroy() {
		for (let label in this._signals)
			this.disconnectWithLabel(label);
	}

	addWithLabel(label /* plus unlimited 3-long array arguments*/) {
		// skip first element of thearguments array;
		let elements = new Array;
		for (let i = 1; i < arguments.length; i++)
			elements.push(arguments[i]);
		this._addSignals(label, elements);
	}

	_addSignals(label, elements) {
		if (this._signals[label] == undefined)
			this._signals[label] = new Array();
		for (let i = 0; i < elements.length; i++) {
			let object = elements[i][0];
			let event = elements[i][1];
			let id = object.connect(event, elements[i][2]);
			this._signals[label].push([object, id]);
		}
	}

	disconnectWithLabel(label) {
		if (this._signals[label]) {
			for (let i = 0; i < this._signals[label].length; i++) {
				this._signals[label][i][0].disconnect(
					this._signals[label][i][1]
				);
			}
			delete this._signals[label];
		}
	}
};

export function getMonitorManager() {
	if (global.backend.get_monitor_manager !== undefined)
		return global.backend.get_monitor_manager();
	else
		return Meta.MonitorManager.get();
}
