/**
 * This file is part of Hide Top Bar (Multi-Monitor)
 *
 * Fork of Hide Top Bar by Thomas Vogt, extended for multi-monitor support.
 *
 * The SecondaryPanel approach in this file is adapted from the "Top Bar All
 * Monitors" extension (topbar-all-monitors@fa8i.github.io), distributed under
 * the GNU General Public License. The original work is credited to its author
 * (fa8i). Only minor modifications were made to integrate it with this fork's
 * architecture; the deferred-publication and preferred-width logic follow the
 * original.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import Meta from 'gi://Meta';
import St from 'gi://St';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Panel from 'resource:///org/gnome/shell/ui/panel.js';

import * as SecondaryVisibilityManager from './secondaryVisibilityManager.js';
import * as Convenience from './convenience.js';
const DEBUG = Convenience.DEBUG;
const MMDEBUG = Convenience.MMDEBUG;

// Upper bound on deferred publication retries. At one retry per idle cycle this
// is a short, self-terminating sequence, never a permanent poll. It only exists
// to cover the brief window during session startup where the actor has an
// allocation but findMonitorForActor() has not yet settled on the final
// geometry.
const MAX_PUBLISH_RETRIES = 20;

// Name used by styling extensions to discover a secondary panel box once its
// geometry is valid, matching the shell's own primary 'panelBox'.
const PANEL_BOX_NAME = 'panelBox';

/**
 * A real GNOME Panel instance bound to a secondary monitor.
 *
 * Each SecondaryPanel is its own Panel.Panel: it builds its own status area and
 * visual actors, so no GObject actor from the primary panel is ever reparented
 * or shared. It only mirrors the primary panel's style class so the active
 * theme is respected.
 */
const SecondaryPanel = GObject.registerClass({
	Signals: { 'allocated': {} },
}, class SecondaryPanel extends Panel.Panel {
	_init(monitorIndex, panelBox) {
		super._init();

		this._monitorIndex = monitorIndex;

		// Panel.Panel inserts itself into the shell's primary panelBox; move it
		// into our own box instead.
		Main.layoutManager.panelBox.remove_child(this);
		panelBox.add_child(this);

		// Follow the primary panel's style class so the active theme applies,
		// without touching the primary panel's own actors.
		Main.panel.connectObject(
			'notify::style-class',
			() => this._syncStyleClass(),
			this
		);

		this._syncStyleClass();
	}

	_syncStyleClass() {
		this.set_style_class_name(Main.panel.get_style_class_name());
	}

	vfunc_get_preferred_width(_forHeight) {
		const monitor = Main.layoutManager.monitors[this._monitorIndex];
		return [0, monitor?.width ?? 0];
	}

	vfunc_allocate(box) {
		super.vfunc_allocate(box);
		// notify::allocation only fires when the box changes; a relayout that
		// keeps the same geometry must still retry publication.
		this.emit('allocated');
	}

	destroy() {
		Main.panel.disconnectObject(this);
		Main.ctrlAltTabManager.removeGroup(this);
		super.destroy();
	}
});

/**
 * Owns a secondary panel plus its chrome box and lifecycle. One per secondary
 * monitor.
 */
export class SecondaryPanelBox {
	constructor(monitorIndex, monitor, settings) {
		DEBUG("SecondaryPanelBox(" + monitorIndex + ")");
		MMDEBUG("SecondaryPanelBox create monitor=" + monitorIndex
			+ " geom=" + monitor.x + "," + monitor.y
			+ " " + monitor.width + "x" + monitor.height);
		this.monitorIndex = monitorIndex;
		this._settings = settings;
		this._publishIdleId = 0;
		this._publishRetries = 0;
		this._visibilityManager = null;

		// Dedicated chrome box positioned on the target monitor's real
		// geometry. Width is clipped to the monitor so nothing overlaps the
		// neighbouring displays.
		this.actor = new St.BoxLayout({
			name: 'hidetopbarMultiMonitorPanelBox',
			style_class: 'hidetopbar-multimonitor-panel-box',
			orientation: Clutter.Orientation.VERTICAL,
			clip_to_allocation: true,
			reactive: true,
			x: monitor.x,
			y: monitor.y,
			width: monitor.width,
		});

		this.panel = new SecondaryPanel(monitorIndex, this.actor);
		this.panel.connectObject(
			'allocated',
			() => this._queuePublishPanel(),
			this.actor
		);

		// Phase 2: secondary panels stay visible and do not reserve work-area
		// space (affectsStruts: false). Strut handling is deferred to a later
		// phase per the project plan.
		Main.layoutManager.addChrome(this.actor, {
			affectsStruts: false,
			trackFullscreen: true,
		});
	}

	/**
	 * Reposition and resize the box for the monitor's current geometry.
	 * Called on monitors-changed via the manager's rebuild, but also safe to
	 * call directly.
	 */
	updateGeometry(monitor) {
		if (!this.actor || !monitor)
			return;
		this.actor.set_position(monitor.x, monitor.y);
		this.actor.set_width(monitor.width);
	}

	_queuePublishPanel() {
		if (this._publishIdleId)
			return;
		if (this._visibilityManager)
			return; // already fully published

		// Wait for allocation before validating position. Deferring also lets
		// any previous relayout settle.
		this._publishIdleId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
			this._publishIdleId = 0;
			this._publishPanel();
			return GLib.SOURCE_REMOVE;
		});
	}

	_publishPanel() {
		if (!this.actor || !this.panel)
			return;

		if (!this.actor.has_allocation() || !this.panel.has_allocation()) {
			MMDEBUG("publish[" + this.monitorIndex + "]: no allocation yet, retry="
				+ this._publishRetries);
			this._retryPublish();
			return;
		}

		// During session startup the actor can have an allocation while
		// findMonitorForActor() still reports a transient/mismatched monitor
		// (coordinates are only final once the startup animation ends). The
		// previous code abandoned publication here and never retried unless a
		// new 'allocated' happened to fire, which is why the panel and its
		// visibility controller were never created at login. Retry a bounded
		// number of times instead of giving up.
		const monitor = Main.layoutManager.findMonitorForActor(this.panel);
		if (monitor?.index !== this.monitorIndex) {
			MMDEBUG("publish[" + this.monitorIndex + "]: monitor mismatch (got "
				+ (monitor ? monitor.index : "null") + "), retry="
				+ this._publishRetries);
			this._retryPublish();
			return;
		}

		// Allow styling extensions to discover the panel once geometry is valid.
		this.panel.disconnectObject(this.actor);
		this.actor.set_name(PANEL_BOX_NAME);
		this._publishRetries = 0;
		MMDEBUG("publish[" + this.monitorIndex + "]: published, box.y="
			+ this.actor.y + " panel.height=" + this.panel.height);

		// Now that the box has a valid allocation (and thus a correct baseline
		// Y), attach the per-monitor visibility controller. It owns the
		// detection strategy and the hide/show animation for this box only.
		if (!this._visibilityManager && this._settings) {
			this._visibilityManager =
				new SecondaryVisibilityManager.SecondaryPanelVisibilityManager(
					this._settings,
					this.monitorIndex,
					this.actor,
					this.panel,
				);
			MMDEBUG("publish[" + this.monitorIndex
				+ "]: visibility controller created");

			// The overview may already be open when this panel is first
			// published (e.g. the extension is enabled, or monitors change,
			// while in Activities). The manager's showing/hiding listeners only
			// fire on transitions, so apply the initial forced-visible state
			// here to cover that case. The manager still owns releasing it on
			// the next 'hiding'.
			if (Main.overview.visible
				&& this._settings.get_boolean('multi-monitor-overview')) {
				MMDEBUG("publish[" + this.monitorIndex
					+ "]: overview already open, forcing visible");
				this._visibilityManager.setForcedVisible(true);
			}
		}
	}

	_retryPublish() {
		if (this._publishIdleId)
			return;
		if (this._publishRetries >= MAX_PUBLISH_RETRIES) {
			MMDEBUG("publish[" + this.monitorIndex
				+ "]: gave up after " + this._publishRetries + " retries");
			return;
		}
		this._publishRetries++;
		this._publishIdleId = GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
			this._publishIdleId = 0;
			this._publishPanel();
			return GLib.SOURCE_REMOVE;
		});
	}

	/**
	 * Force this panel visible regardless of its strategy (overview use in
	 * phase 3B). Safe no-op until the controller exists.
	 */
	setForcedVisible(forced) {
		this._visibilityManager?.setForcedVisible(forced);
	}

	destroy() {
		DEBUG("SecondaryPanelBox.destroy(" + this.monitorIndex + ")");
		MMDEBUG("SecondaryPanelBox destroy monitor=" + this.monitorIndex);
		if (this._publishIdleId) {
			GLib.Source.remove(this._publishIdleId);
			this._publishIdleId = 0;
		}

		// Tear down the visibility controller (and its strategy) before the
		// actor it animates is destroyed, so no transition or callback can run
		// against a freed actor.
		if (this._visibilityManager) {
			this._visibilityManager.destroy();
			this._visibilityManager = null;
		}

		if (this.panel) {
			this.panel.disconnectObject(this.actor);
			this.panel.destroy();
			this.panel = null;
		}

		if (this.actor) {
			Main.layoutManager.removeChrome(this.actor);
			this.actor.destroy();
			this.actor = null;
		}
	}
}
