# Hide Top Bar (Multi-Monitor)

A GNOME Shell extension that hides the top bar and adds **independent,
intelligent top bars to every monitor**. It is a fork of
[Hide Top Bar](https://github.com/tuxor1337/hidetopbar) by Thomas Vogt,
extended with multi-monitor support, per-monitor hide strategies and GNOME
Overview integration.

> Status: **`0.1.0-beta.1`** — early beta. Multi-monitor behaviour tested on
> GNOME 50. On GNOME 51 the extension loads and preferences open on a single
> monitor; multi-monitor there is not yet validated. See
> [Compatibility](#compatibility).

## Multi-monitor support

![Hide Top Bar running on two monitors](icons/topbarmultimonitor.jpg)

## Preferences

![Hide Top Bar (Multi-Monitor) preferences](icons/panel.png)

## Features

- Hides the top bar on the **primary monitor**, preserving the original Hide
  Top Bar behaviour (intellihide, mouse-edge reveal, keyboard shortcut,
  Activities handling, animations and all original preferences).
- Optional **top bar on every secondary monitor**, each a real GNOME panel
  with its own clock and status area that follows the active theme.
- **Independent per-monitor hiding**: each panel decides whether to hide based
  only on the windows of its own monitor.
- Two selectable hide strategies (see [Hide modes](#hide-modes)).
- **Overview integration**: optionally reveal all panels when entering
  Activities and restore each monitor's state when leaving.
- Dynamic handling of monitor connect/disconnect and primary-monitor changes.
- Independent GSettings schema, so it does not conflict with the original Hide
  Top Bar if both are installed.

## Differences from the original Hide Top Bar

| Aspect | Hide Top Bar | Hide Top Bar (Multi-Monitor) |
|---|---|---|
| Monitors managed | Primary only | Primary + all secondaries (optional) |
| Secondary panels | None | A real top bar per secondary monitor |
| Hiding decision | Primary panel | Independent per monitor |
| Hide strategies | Intellihide (overlap) | `overlap` and `visible-windows` |
| Overview | Primary panel | All panels (optional) |
| GSettings schema | `org.gnome.shell.extensions.hidetopbar` | `org.gnome.shell.extensions.hidetopbar-multimonitor` |

When multi-monitor mode is **off**, the extension behaves exactly like the
original Hide Top Bar and only manages the primary monitor.

## Requirements

- GNOME Shell 50 or 51 (see [Compatibility](#compatibility)).
- Wayland or X11 (developed and tested on Wayland).

## Manual installation

```sh
# From the repository root, copy the extension directory into place:
cp -r "hidetopbar-multimonitor@linuxitos.local" \
   ~/.local/share/gnome-shell/extensions/

# Compile the settings schema:
glib-compile-schemas \
   ~/.local/share/gnome-shell/extensions/hidetopbar-multimonitor@linuxitos.local/schemas/
```

On Wayland, log out and back in for GNOME Shell to pick up the new extension,
then enable it:

```sh
gnome-extensions enable hidetopbar-multimonitor@linuxitos.local
```

## Configuration

Open the preferences:

```sh
gnome-extensions prefs hidetopbar-multimonitor@linuxitos.local
```

All original Hide Top Bar preferences are available and apply globally. The
**Multi-Monitor** section adds:

- **Enable multi-monitor top bars** — create a top bar on every monitor. When
  off, the extension behaves like the original.
- **Independent intellihide per monitor** — each secondary panel hides based on
  the windows of its own monitor.
- **Show all top bars in overview** — reveal every monitor's top bar when
  entering Activities.
- **Multi-monitor hide mode** — selects the strategy (see below).

## Hide modes

- **Original Intellihide (`overlap`)** — the default. A panel hides only when a
  relevant window overlaps the panel area of that monitor, reproducing the
  original Hide Top Bar logic per monitor.
- **Visible windows (`visible-windows`)** — a monitor's panel hides whenever at
  least one normal, visible, non-minimised window exists on that monitor,
  regardless of focus, window size or whether the window touches the panel.
  Minimising or closing all windows on a monitor shows that monitor's panel
  again, independently of the others.

Both strategies evaluate windows per monitor and on the active workspace.

## Overview behaviour

With **Show all top bars in overview** enabled, entering Activities reveals the
top bars on all monitors; leaving Activities re-applies each monitor's hide
strategy. With the option disabled, panels keep their own strategy state during
Overview. The primary panel always keeps the original Hide Top Bar overview
behaviour.

## Compatibility

| GNOME Shell | Status |
|---|---|
| 50 | Multi-monitor and Overview behaviour tested (Fedora 44, Wayland). |
| 51 | Loads, preferences open, and the Spanish UI is translated correctly on a single monitor (Fedora 45). **Multi-monitor behaviour not yet validated.** |

`metadata.json` declares support for GNOME **50** and **51**. On GNOME 51 only
single-monitor loading and preferences have been verified so far; multi-monitor
testing there is still pending.

## Known limitations

- **Third-party panel indicators appear only on the primary monitor.**
  Extensions such as AppIndicator Support, Tray Icons Reloaded and Quick
  Settings add-ons inject their indicators into the primary `Main.panel` only.
  Secondary panels show the standard GNOME status area (clock, etc.) without
  those third-party indicators. Mirroring them is not done, to avoid reparenting
  global actors and causing conflicts.
- Secondary panels use `affectsStruts: false`, so a maximised window may appear
  underneath a visible secondary bar. This is intentional for now.
- Cursor-edge reveal (pressure barrier) is implemented for the primary panel
  only; secondary panels do not yet reveal on mouse edge.
- Translations are inherited from the original Hide Top Bar; see
  [Credits](#credits-and-attribution).

## Troubleshooting

- **A secondary panel does not appear after login.** Make sure multi-monitor
  mode is enabled in preferences. If it still does not appear, check the log:
  `journalctl --user -b -o cat /usr/bin/gnome-shell | grep -i hidetopbar`.
- **Enable verbose diagnostics.** Set `MM_DEBUG_ENABLED` to `true` in
  `convenience.js` to emit `[HTB-MM]` lifecycle logs, then filter with
  `journalctl --user -f -o cat /usr/bin/gnome-shell | grep HTB-MM`. It is `false`
  by default.
- **Return to the original Hide Top Bar.** Disable multi-monitor mode, or disable
  the extension. The schema path is independent
  (`/org/gnome/shell/extensions/hidetopbar-multimonitor/`), so it never clashes
  with the original.

## Translations

The interface is translatable via gettext (domain
`hidetopbar-multimonitor@linuxitos.local`). Editable sources live in `po/`.

- **Fully translated:** English (source), Spanish (`es`), Mexican Spanish
  (`es_MX`).
- **Inherited from the original Hide Top Bar** (original strings translated;
  the multi-monitor strings currently fall back to English): Catalan (`ca`),
  German (`de`), French (`fr`), Italian (`it_IT`), Dutch (`nl`), Polish (`pl`),
  Brazilian Portuguese (`pt_BR`), Russian (`ru_RU`), Simplified Chinese
  (`zh_CN`).

Original translator credits are preserved in each `.po` header and in
[`AUTHORS`](AUTHORS). Contributions of new translations are welcome; see
[`po/README.md`](po/README.md).

## Credits and attribution

This project reuses and adapts GPL-compatible code from several projects. See
[`NOTICE`](NOTICE) and [`AUTHORS`](AUTHORS) for full details.

- **Hide Top Bar** — Thomas Vogt and contributors (GPL-3.0-or-later).
  <https://github.com/tuxor1337/hidetopbar>
- **Dash to Dock** — portions of `intellihide.js` (GPL-2.0-or-later).
  <https://github.com/micheleg/dash-to-dock>
- **Top Bar All Monitors** — fa8i; `secondaryPanel.js` is adapted from it
  (GPL-3.0-or-later). <https://github.com/fa8i/topbar-all-monitors>
- **Desktop Icons NG integration** — Sergio Costas; `desktopIconsIntegration.js`
  (BSD-1-clause).

Multi-monitor support, the per-monitor visibility controllers, the
`visible-windows` strategy, Overview coordination and startup fixes were
developed for this fork by linuxitos.

## License

Distributed under the **GNU General Public License, version 3 or later**
(GPL-3.0-or-later). See [`COPYING.txt`](COPYING.txt) for the full text.

Based on Hide Top Bar by Thomas Vogt and contributors.
