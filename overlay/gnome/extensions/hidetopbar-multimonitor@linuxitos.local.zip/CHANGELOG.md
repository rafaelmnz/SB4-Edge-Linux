# Changelog

All notable changes to this project are documented here. This project is a fork
of [Hide Top Bar](https://github.com/tuxor1337/hidetopbar); only the changes
introduced by the fork are listed.

The format is based on [Keep a Changelog](https://keepachangelog.com/).

## [0.1.0-beta.1] — unreleased

First public beta of the multi-monitor fork.

### Added
- Multi-monitor orchestration (`MultiMonitorManager`): creates and destroys an
  independent top bar on every secondary monitor, keyed per monitor, rebuilt on
  monitor connect/disconnect, reorder and primary-monitor changes.
- Secondary top bars (`SecondaryPanel`): a real GNOME panel per secondary
  monitor, with its own status area, following the primary panel's style class
  (active theme). Positioned on each monitor's real geometry with
  `affectsStruts: false`.
- Per-monitor visibility controller (`SecondaryPanelVisibilityManager`): slides
  each secondary panel on/off independently, without touching shell-global
  resources.
- Two hide strategies, selectable via `multi-monitor-hide-mode`:
  - `overlap`: the original Hide Top Bar intellihide, filtered per monitor.
  - `visible-windows`: hide a monitor's panel whenever a normal, visible,
    non-minimised window exists on that monitor, independent of focus.
- GNOME Overview coordination for secondary panels: optionally reveal all
  panels on entering Activities and restore each monitor's state on leaving,
  gated by `multi-monitor-overview`.
- New GSettings keys: `multi-monitor-enabled`, `multi-monitor-intellihide`,
  `multi-monitor-overview`, `multi-monitor-hide-mode`.
- Multi-monitor section in the preferences UI.
- Independent GSettings schema
  (`org.gnome.shell.extensions.hidetopbar-multimonitor`) and UUID
  (`hidetopbar-multimonitor@linuxitos.local`), so the fork coexists with the
  original Hide Top Bar without configuration conflicts.
- Optional `[HTB-MM]` diagnostic logging, disabled by default.

### Changed
- `PanelVisibilityManager` parametrised to accept a target panel box, an
  `isPrimary` flag and a hide strategy, so shell-global resources (message tray
  patch, overview search padding, hot corner, keyboard shortcut) are owned only
  by the primary controller.

### Fixed
- Secondary panels failing to appear at session login: the panel is now
  published once monitor geometry is final (bounded retry) and a
  `startup-complete` handler covers the startup window.

### Internationalization
- gettext catalogues for the extension's own domain
  (`hidetopbar-multimonitor@linuxitos.local`), covering `Settings.ui` and the
  multi-monitor preferences in `prefs.js`.
- Full Spanish (`es`) and Mexican Spanish (`es_MX`) translations.
- Inherited translations from the original Hide Top Bar for `ca`, `de`, `fr`,
  `it_IT`, `nl`, `pl`, `pt_BR`, `ru_RU`, `zh_CN` (original strings translated;
  multi-monitor strings fall back to English). Original translator credits are
  preserved in each `.po` header.
- Editable `.po`/`.pot` sources under `po/`.

### Compatibility
- `metadata.json` declares GNOME Shell **50** and **51**.
- GNOME Shell 50 (Fedora 44, Wayland): multi-monitor and Overview behaviour
  tested.
- GNOME Shell 51 (Fedora 45): extension loads, preferences open, and the
  Spanish UI is translated correctly on a single monitor. Multi-monitor
  behaviour on GNOME 51 is **not yet validated**.

### Notes
- Classic behaviour is preserved exactly when `multi-monitor-enabled` is off.
