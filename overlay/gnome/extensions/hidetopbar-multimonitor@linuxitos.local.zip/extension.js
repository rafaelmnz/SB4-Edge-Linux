/**
 * This file is part of Hide Top Bar (Multi-Monitor)
 *
 * Copyright 2020 Thomas Vogt
 * Multi-monitor fork 2026 linuxitos
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import * as MultiMonitorManager from './multiMonitorManager.js';
import * as Convenience from './convenience.js';
const DEBUG = Convenience.DEBUG;
const MMDEBUG = Convenience.MMDEBUG;

import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';

let mSettings = null;
let mManager = null;

export default class HideTopBarMultiMonitorExtension extends Extension {
	constructor(metadata) {
		super(metadata);
		// Diagnostic only; gated by MM_DEBUG_ENABLED (false by default) so the
		// extension does not log during initialization in normal use.
		MMDEBUG(`Initiating ${this.uuid}`);
	}

	enable() {
		DEBUG("enable()");
		mSettings = this.getSettings();
		mManager = new MultiMonitorManager.MultiMonitorManager(
			mSettings, this.uuid
		);
	}

	disable() {
		DEBUG("disable()");
		mManager.destroy();

		mManager = null;
		mSettings = null;
	}
}
