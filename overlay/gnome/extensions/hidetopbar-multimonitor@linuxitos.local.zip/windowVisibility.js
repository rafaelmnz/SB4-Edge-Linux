/**
 * This file is part of Hide Top Bar (Multi-Monitor)
 *
 * Fork of Hide Top Bar by Thomas Vogt, extended for multi-monitor support.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import GLib from 'gi://GLib';
import Meta from 'gi://Meta';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Signals from 'resource:///org/gnome/shell/misc/signals.js';

import * as Convenience from './convenience.js';

const DEBUG = Convenience.DEBUG;

// Debounce interval for batching rapid window/workspace changes, mirroring the
// responsiveness/efficiency compromise used by intellihide.js.
const CHECK_INTERVAL = 100;

/**
 * WindowVisibility implements the "visible-windows" hide strategy for a single
 * monitor. It exposes the same minimal surface as Intellihide so the visibility
 * controller can treat both strategies uniformly:
 *   - enable() / disable()
 *   - getOverlapStatus()  -> true means "a window requires the panel to hide"
 *   - 'status-changed' signal
 *
 * The decision is intentionally focus-independent: the panel of a monitor must
 * hide when at least one normal, visible, non-minimised window exists on that
 * monitor, regardless of which window has keyboard focus or which monitor the
 * user is working on.
 *
 * Signals are shared and connected once (on global.display,
 * global.window_manager and the workspace manager), never one connection per
 * window, and updates are debounced through a single GLib timeout.
 */
export class WindowVisibility extends Signals.EventEmitter {
    constructor(settings, monitorIndex) {
        super();
        this._settings = settings;
        this._monitorIndex = monitorIndex;

        this._isEnabled = false;
        this._status = false;      // true => hide required
        this._checkTimeoutId = 0;
        this._checkPending = false;

        this._signalsHandler = new Convenience.GlobalSignalsHandler();
    }

    destroy() {
        this.disable();
    }

    enable() {
        if (this._isEnabled)
            return;
        this._isEnabled = true;
        this._status = false;

        // Shared signals: these cover open/close, minimise/restore (via
        // restacked + size/position changes), moving windows between monitors
        // and workspace switches, without a per-window connection explosion.
        this._signalsHandler.add(
            [global.display, 'window-created', () => this._queueCheck()],
            [global.display, 'restacked', () => this._queueCheck()],
            [global.display, 'grab-op-end', () => this._queueCheck()],
            [
                global.window_manager,
                'minimize',
                () => this._queueCheck(),
            ],
            [
                global.window_manager,
                'unminimize',
                () => this._queueCheck(),
            ],
            [
                global.window_manager,
                'size-changed',
                () => this._queueCheck(),
            ],
            [
                global.workspace_manager,
                'active-workspace-changed',
                () => this._queueCheck(),
            ],
            [
                Main.layoutManager,
                'monitors-changed',
                () => this._queueCheck(),
            ],
        );

        this._doCheck();
    }

    disable() {
        this._isEnabled = false;
        this._signalsHandler.destroy();
        this._signalsHandler = new Convenience.GlobalSignalsHandler();
        if (this._checkTimeoutId) {
            GLib.source_remove(this._checkTimeoutId);
            this._checkTimeoutId = 0;
        }
        this._checkPending = false;
    }

    // Keep the same accessor name as Intellihide: true means the panel should
    // hide.
    getOverlapStatus() {
        return this._status;
    }

    // Allow the controller to request a re-evaluation (e.g. after an overview
    // transition). No target box is needed for this strategy, so the argument
    // is accepted and ignored for API symmetry with Intellihide.
    updateTargetBox(_box) {
        this._queueCheck();
    }

    forceUpdate() {
        this._status = !this._status; // force emit on next check
        this._doCheck();
    }

    _queueCheck() {
        if (!this._isEnabled)
            return;
        if (this._checkTimeoutId) {
            this._checkPending = true;
            return;
        }
        this._doCheck();
        this._checkTimeoutId = GLib.timeout_add(
            GLib.PRIORITY_DEFAULT, CHECK_INTERVAL, () => {
                this._doCheck();
                if (this._checkPending) {
                    this._checkPending = false;
                    return GLib.SOURCE_CONTINUE;
                }
                this._checkTimeoutId = 0;
                return GLib.SOURCE_REMOVE;
            }
        );
    }

    _doCheck() {
        if (!this._isEnabled)
            return;

        const hide = this._hasVisibleWindow();
        if (hide !== this._status) {
            this._status = hide;
            this.emit('status-changed', this._status);
        }
    }

    /**
     * Returns true if at least one normal, visible, non-minimised application
     * window exists on this monitor and the active workspace.
     */
    _hasVisibleWindow() {
        const activeWs = global.workspace_manager.get_active_workspace();
        if (!activeWs)
            return false;

        const windows = activeWs.list_windows();
        for (const win of windows) {
            if (this._isRelevantWindow(win))
                return true;
        }
        return false;
    }

    _isRelevantWindow(win) {
        if (!win)
            return false;

        // Only normal application windows count. This excludes DESKTOP, DOCK,
        // menus, tooltips, notifications, splash screens and other shell
        // internals.
        if (win.get_window_type() !== Meta.WindowType.NORMAL)
            return false;

        // Skip windows that are not shown (minimised or not on this workspace's
        // visible set).
        if (win.minimized)
            return false;
        if (!win.showing_on_its_workspace())
            return false;

        // Skip taskbar-less utility/override windows.
        if (win.is_skip_taskbar())
            return false;

        // Must belong to this monitor.
        if (win.get_monitor() !== this._monitorIndex)
            return false;

        return true;
    }
}
