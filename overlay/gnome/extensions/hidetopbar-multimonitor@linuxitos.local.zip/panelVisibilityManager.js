/**
 * This file is part of Hide Top Bar
 *
 * Copyright 2020 Thomas Vogt
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import Clutter from 'gi://Clutter';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Layout from 'resource:///org/gnome/shell/ui/layout.js';
import * as Config from 'resource:///org/gnome/shell/misc/config.js';
const [major] = Config.PACKAGE_VERSION.split('.');
const shellVersion = Number.parseInt(major);

import * as Convenience from './convenience.js';
import * as Intellihide from './intellihide.js';
import * as WindowVisibility from './windowVisibility.js';
import * as DesktopIconsIntegration from './desktopIconsIntegration.js';
const DEBUG = Convenience.DEBUG;

const MessageTray = Main.messageTray;
const ShellActionMode = (
	Shell.ActionMode ? Shell.ActionMode : Shell.KeyBindingMode
);

export class PanelVisibilityManager {

	/**
	 * @param {Gio.Settings} settings  extension settings
	 * @param {number} monitorIndex    monitor this controller is bound to
	 * @param {object} [options]       controller options
	 * @param {Clutter.Actor} [options.panelBox]  panel box actor to manage.
	 *        Defaults to the shell's primary panelBox.
	 * @param {boolean} [options.isPrimary]  whether this controller owns the
	 *        shell-global resources (banner patch, overview search padding,
	 *        hot corner, keybinding). Defaults to true. Fase 1 always uses the
	 *        primary monitor, so the default preserves the original behaviour.
	 */
	constructor(settings, monitorIndex, options = {}) {
		this._monitorIndex = monitorIndex;
		this._settings = settings;

		// Target panel box. The primary controller manages the shell's own
		// panelBox; secondary controllers (Fase 2+) will pass their own actor.
		this._panelBox = options.panelBox ?? Main.layoutManager.panelBox;
		this._isPrimary = options.isPrimary ?? true;

		// Detection strategy for this panel. Defaults to the original
		// intellihide ('overlap') so classic behaviour is preserved exactly.
		// The manager may pass 'visible-windows' when multi-monitor mode is on.
		this._hideStrategy = options.hideStrategy ?? 'overlap';

		const PanelBox = this._panelBox;

		this._base_y = PanelBox.y;
		this._preventHide = false;
		this._showInOverview = true;
		this._intellihideBlock = false;
		this._staticBox = new Clutter.ActorBox();
		this._animationActive = false;
		this._shortcutTimeout = null;
		this._unredirectDisabled = false;

		// Shell-global overview search entry. Only the primary controller
		// adjusts its padding so secondary controllers never touch it.
		this._searchEntryBin = this._isPrimary
			? Main.overview?._overview?._controls?._searchEntryBin
			: null;

		this._desktopIconsUsableArea = (
			new DesktopIconsIntegration.DesktopIconsUsableAreaClass(
				options.uuid
			)
		);
		Main.layoutManager.removeChrome(PanelBox);
		Main.layoutManager.addChrome(PanelBox, {
			affectsStruts: false,
			trackFullscreen: true
		});

		// We lost the original notification's position because of
		// PanelBox->affectsStruts = false and now it appears beneath the
		// top bar, fix it. This is a shell-global patch, so only the primary
		// controller installs it.
		if (this._isPrimary) {
			this._oldEase = MessageTray._bannerBin.ease;
			MessageTray._bannerBin.ease = (
				function (params) {
					if (params.hasOwnProperty("y") && PanelBox.y >= 0) {
						params.y += PanelBox.height;
					}
					this._oldEase.apply(MessageTray._bannerBin, arguments);
				}
			).bind(this);
		}

		this._cursorTracker = (
			(typeof global.backend?.get_cursor_tracker === "function")
				? global.backend.get_cursor_tracker()
				: Meta.CursorTracker.get_for_display(global.display)  // GNOME Shell 45-47
		);
		this._pointerListener = null;

		// Load settings
		this._bindSettingsChanges();
		this._updateSettingsMouseSensitive();
		this._updateSettingsShowInOverview();
		// The strategy exposes the same surface in both cases
		// (enable/disable/updateTargetBox/getOverlapStatus/'status-changed'),
		// so the rest of this controller is strategy-agnostic. The property is
		// kept named `_intellihide` to minimise churn in the original logic.
		if (this._hideStrategy === 'visible-windows') {
			this._intellihide = new WindowVisibility.WindowVisibility(
				this._settings, this._monitorIndex,
			);
		} else {
			this._intellihide = new Intellihide.Intellihide(
				this._settings, this._monitorIndex,
			);
		}

		this._updateHotCorner(false);
		this._updateStaticBox();
		// Wait until the panel has an allocation: after login this can take
		// a second or two, and on unlock a relayout can still be queued.
		// notify::allocation is not enough, it only fires if the box changes.
		this._bindTimeoutId = GLib.timeout_add(
			GLib.PRIORITY_DEFAULT, 100, () => {
				if (!PanelBox.has_allocation())
					return GLib.SOURCE_CONTINUE;
				this._bindTimeoutId = 0;
				this._bindUIChanges();
				return GLib.SOURCE_REMOVE;
			}
		);
	}

	hide(animationTime, trigger) {
		DEBUG("hide(" + trigger + ")");
		if (this._preventHide) return;

		const PanelBox = this._panelBox;
		let anchor_y = PanelBox.get_pivot_point()[1],
			delta_y = -PanelBox.height;
		if (anchor_y < 0) delta_y = -delta_y;
		let mouse = global.get_pointer();
		if (trigger == "mouse-left" && this._isHovering(...mouse)) return;

		this._stopWatchingPointer();

		if (this._animationActive) {
			PanelBox.remove_all_transitions();
			this._animationActive = false;
		}

		this._animationActive = true;
		PanelBox.ease({
			y: this._base_y + delta_y,
			duration: animationTime * 1000,
			mode: Clutter.AnimationMode.EASE_OUT_QUAD,
			onComplete: () => {
				this._animationActive = false;
				if (!this._settings.get_boolean('keep-round-corners')) {
					PanelBox.hide();
				}
				this._updateHotCorner(true);
				this._setUnredirectDisabled(false);
			}
		});
	}

	// While the panel is on screen above a window that covers the whole
	// monitor, that window must not be unredirected (X11) or put on a
	// direct-scanout plane (Wayland): the compositor would skip painting
	// the stage and the panel would stay invisible although it still
	// receives input. GNOME Shell does the same for its own notifications,
	// OSDs and menus. The calls are counted by Mutter, so keep them paired.
	_setUnredirectDisabled(disabled) {
		if (disabled === this._unredirectDisabled) return;
		if (shellVersion >= 48) {
			if (disabled)
				global.compositor.disable_unredirect();
			else
				global.compositor.enable_unredirect();
		} else {
			if (disabled)
				Meta.disable_unredirect_for_display(global.display);
			else
				Meta.enable_unredirect_for_display(global.display);
		}
		this._unredirectDisabled = disabled;
	}

	show(animationTime, trigger) {
		DEBUG("show(" + trigger + ")");
		const PanelBox = this._panelBox;
		if (trigger == "mouse-enter"
			&& this._settings.get_boolean('mouse-triggers-overview')) {
			Main.overview.show();
		}

		if (this._animationActive) {
			PanelBox.remove_all_transitions();
			this._animationActive = false;
		}

		this._updateHotCorner(false);
		PanelBox.show();
		this._setUnredirectDisabled(trigger != "destroy");
		if (trigger == "destroy"
			|| (
				trigger == "showing-overview"
				&& global.get_pointer()[1] < PanelBox.height
				&& this._settings.get_boolean('hot-corner')
			)
		) {
			PanelBox.y = this._base_y;
		} else {
			this._animationActive = true;
			PanelBox.ease({
				y: this._base_y,
				duration: animationTime * 1000,
				mode: Clutter.AnimationMode.EASE_OUT_QUAD,
				onComplete: () => {
					this._animationActive = false;
					this._updateStaticBox();

					const mouse = global.get_pointer();

					if (!this._isHovering(...mouse)) {
						// The cursor has already left the panel, so we can
						// start hiding the panel immediately.
						this._handleMenus();
					}
					else if (!this._pointerListener) {
						// The cursor is still on the panel. Start watching the
						// pointer so we know when it leaves the panel.
						this._pointerListener = this._cursorTracker.connect(
							'position-invalidated',
							() => this._handlePointer(...global.get_pointer()),
						);
					}
				}
			});
		}
	}

	_isHovering(x, y) {
		return (y >= this._staticBox.y1 &&
			y < this._staticBox.y2 &&
			x >= this._staticBox.x1 &&
			x < this._staticBox.x2);
	}

	_stopWatchingPointer() {
		if (this._pointerListener) {
			this._cursorTracker.disconnect(this._pointerListener);
			this._pointerListener = null;
		}
	}

	_handlePointer(x, y) {
		if (!this._animationActive && !this._isHovering(x, y)) {
			this._handleMenus();
		}
	}

	_handleMenus() {
		if (!Main.overview.visible) {
			let blocker = Main.panel.menuManager.activeMenu;
			if (blocker == null) {
				this.hide(
					this._settings.get_double('animation-time-autohide'),
					"mouse-left"
				);
			} else {
				this._blockerMenu = blocker;
				this._menuEvent = this._blockerMenu.connect(
					'open-state-changed',
					(menu, open) => {
						if (!open && this._blockerMenu !== null) {
							this._blockerMenu.disconnect(this._menuEvent);
							this._menuEvent = null;
							this._blockerMenu = null;
							this._handleMenus();
						}
					}
				);
			}
		}
	}

	_handleShortcut() {
		let delay_time = this._settings.get_double('shortcut-delay');
		if (this._shortcutTimeout) {
			if (this._shortcutTimeout !== true) {
				GLib.source_remove(this._shortcutTimeout);
			}
			this._shortcutTimeout = null;
			if (delay_time < 0.05
				|| this._settings.get_boolean('shortcut-toggles')) {
				this._intellihideBlock = false;
				this._preventHide = false;
				this.hide(
					this._settings.get_double('animation-time-autohide'),
					"shortcut"
				);
				return;
			}
		}

		// If setting 'shortcut-toggles' is false, repeatedly pressing the
		// shortcut should prevent the bar from hiding
		if (!this._preventHide || this._intellihideBlock) {
			this._intellihideBlock = true;
			this._preventHide = true;

			if (delay_time > 0.05) {
				let show_time = Math.min(
					this._settings.get_double('animation-time-autohide'),
					Math.max(0.1, delay_time / 5.0));
				this.show(show_time, "shortcut");

				this._shortcutTimeout = GLib.timeout_add(
					GLib.PRIORITY_DEFAULT, delay_time * 1200,
					() => {
						this._preventHide = false;
						this._intellihideBlock = false;
						this._handleMenus();
						this._shortcutTimeout = null;
						return false;
					}
				);
			} else {
				this.show(
					this._settings.get_double('animation-time-autohide'),
					"shortcut"
				);
				this._shortcutTimeout = true;
			}
			// Key-focus the "Activities" button
			//  Currently, this is deactivated because we can't make sure that
			//  the panel doesn't hide as long as it has the key focus.
			// Main -> panel -> _leftBox -> (StBin) -> (panel-button)
			// Main.panel._leftBox.first_child.first_child.grab_key_focus();
		}
	}

	_disablePressureBarrier() {
		this._stopWatchingPointer();

		if (this._panelBarrier && this._panelPressure) {
			this._panelPressure.removeBarrier(this._panelBarrier);
			this._panelBarrier.destroy();
			this._panelBarrier = null;
		}
	}

	_initPressureBarrier() {
		const PanelBox = this._panelBox;
		this._panelPressure = new Layout.PressureBarrier(
			this._settings.get_int('pressure-threshold'),
			this._settings.get_int('pressure-timeout'),
			ShellActionMode.NORMAL
		);
		this._panelPressure.connect(
			'trigger',
			(barrier) => {
				if (
					Main.layoutManager.primaryMonitor?.inFullscreen
					&& !this._settings.get_boolean(
						'mouse-sensitive-fullscreen-window'
					)
				) {
					return;
				}
				this.show(
					this._settings.get_double('animation-time-autohide'),
					"mouse-enter"
				);
			}
		);
		let anchor_y = PanelBox.get_pivot_point()[1],
			direction = Meta.BarrierDirection.POSITIVE_Y;
		if (anchor_y < 0) {
			anchor_y -= PanelBox.height;
			direction = Meta.BarrierDirection.NEGATIVE_Y;
		}
		this._panelBarrier = new Meta.Barrier({
			...(shellVersion === 45 ? { display: global.display } : { backend: global.backend }),
			x1: PanelBox.x,
			x2: PanelBox.x + PanelBox.width,
			y1: this._base_y - anchor_y,
			y2: this._base_y - anchor_y,
			directions: direction
		});
		this._panelPressure.addBarrier(this._panelBarrier);
	}

	_updateStaticBox() {
		DEBUG("_updateStaticBox()");
		const PanelBox = this._panelBox;
		let anchor_y = PanelBox.get_pivot_point()[1];
		this._staticBox.init_rect(
			PanelBox.x, PanelBox.y - anchor_y, PanelBox.width, PanelBox.height
		);
		this._intellihide.updateTargetBox(this._staticBox);
		this._desktopIconsUsableArea.resetMargins();
		this._desktopIconsUsableArea.setMargins(-1, PanelBox.height, 0, 0, 0);
	}

	_updateHotCorner(panel_hidden) {
		// The hot corner is a shell-global resource owned by the primary
		// monitor. Secondary controllers never touch it.
		if (!this._isPrimary) return;
		const PanelBox = this._panelBox;
		let HotCorner = null;
		for (let i = 0; i < Main.layoutManager.hotCorners.length; i++) {
			let hc = Main.layoutManager.hotCorners[i];
			if (hc) {
				HotCorner = hc;
				break;
			}
		}
		if (HotCorner) {
			if (!panel_hidden || this._settings.get_boolean('hot-corner')) {
				HotCorner.setBarrierSize(PanelBox.height);
			} else {
				GLib.timeout_add(GLib.PRIORITY_DEFAULT, 100, function () {
					HotCorner.setBarrierSize(0)
				});
			}
		}
	}

	_updateSettingsHotCorner() {
		this.hide(0.1, "hot-corner-setting-changed");
	}

	_updateSettingsMouseSensitive() {
		if (this._settings.get_boolean('mouse-sensitive')) {
			this._disablePressureBarrier();
			this._initPressureBarrier();
		} else this._disablePressureBarrier();
	}

	_updateSettingsShowInOverview() {
		this._showInOverview = this._settings.get_boolean('show-in-overview');
		this._updateSearchEntryPadding();
	}

	_updateSearchEntryPadding() {
		// Overview search entry padding is a shell-global adjustment owned by
		// the primary controller.
		if (!this._isPrimary) return;
		const _searchEntryBin = this._searchEntryBin;
		if (!_searchEntryBin) return;
		if (!Main.layoutManager.primaryMonitor) return;
		const scale = Main.layoutManager.primaryMonitor.geometry_scale;
		const offset = this._panelBox.height / scale;
		_searchEntryBin.set_style(
			this._showInOverview ? `padding-top: ${offset}px;` : null
		);
	}

	_updateIntellihideStatus() {
		if (this._settings.get_boolean('enable-intellihide')) {
			this._intellihideBlock = false;
			this._preventHide = false;
			this._intellihide.enable();
		} else {
			this._intellihide.disable();
			this._intellihideBlock = true;
			this._preventHide = false;
			this.hide(0, "init");
		}
	}

	_updatePreventHide() {
		if (this._intellihideBlock) return;

		this._preventHide = !this._intellihide.getOverlapStatus();
		let animTime = this._settings.get_double('animation-time-autohide');
		if (this._preventHide) {
			if (this._showInOverview || !Main.overview.visible)
				this.show(animTime, "intellihide");
		} else if (!Main.overview.visible)
			this.hide(animTime, "intellihide");
	}

	_bindUIChanges() {
		const PanelBox = this._panelBox;
		this._signalsHandler.add(
			[
				Main.overview,
				'showing',
				() => {
					if (this._showInOverview) {
						this.show(
							this._settings.get_double(
								'animation-time-overview'
							),
							"showing-overview"
						);
					}
				}
			],
			[
				Main.overview,
				'hiding',
				() => {
					this.hide(
						this._settings.get_double('animation-time-overview'),
						"hiding-overview"
					);
				}
			],
			[
				Main.panel,
				'leave-event',
				this._handleMenus.bind(this)
			],
			[
				PanelBox,
				'notify::anchor-y',
				() => {
					this._updateStaticBox();
					this._updateSettingsMouseSensitive();
				}
			],
			[
				PanelBox,
				'notify::height',
				this._updateSearchEntryPadding.bind(this)
			],
			[
				Main.layoutManager,
				'monitors-changed',
				() => {
					this._base_y = PanelBox.y;
					this._updateStaticBox();
					this._updateSettingsMouseSensitive();
					// LayoutManager._updateBoxes() has just moved PanelBox
					// back on screen: hide it again unless it is held.
					this._handleMenus();
				}
			],
			[
				this._intellihide,
				'status-changed',
				this._updatePreventHide.bind(this)
			]
		);

		// The keyboard shortcut is a shell-global keybinding; only the primary
		// controller registers it. The orchestrator forwards shortcut-driven
		// reveals to secondary controllers in a later phase.
		if (this._isPrimary) {
			Main.wm.addKeybinding("shortcut-keybind",
				this._settings, Meta.KeyBindingFlags.NONE,
				ShellActionMode.NORMAL,
				this._handleShortcut.bind(this)
			);
		}

		this._updateIntellihideStatus();
	}

	_bindSettingsChanges() {
		this._signalsHandler = new Convenience.GlobalSignalsHandler();
		this._signalsHandler.addWithLabel("settings",
			[
				this._settings,
				'changed::hot-corner',
				this._updateSettingsHotCorner.bind(this)
			],
			[
				this._settings,
				'changed::mouse-sensitive',
				this._updateSettingsMouseSensitive.bind(this)
			],
			[
				this._settings,
				'changed::pressure-timeout',
				this._updateSettingsMouseSensitive.bind(this)
			],
			[
				this._settings,
				'changed::pressure-threshold',
				this._updateSettingsMouseSensitive.bind(this)
			],
			[
				this._settings,
				'changed::show-in-overview',
				this._updateSettingsShowInOverview.bind(this)
			],
			[
				this._settings,
				'changed::enable-intellihide',
				this._updateIntellihideStatus.bind(this)
			],
			[
				this._settings,
				'changed::enable-active-window',
				this._updateIntellihideStatus.bind(this)
			]
		);
	}

	destroy() {
		const PanelBox = this._panelBox;
		if (this._bindTimeoutId) {
			GLib.source_remove(this._bindTimeoutId);
			this._bindTimeoutId = 0;
		}
		this._intellihide.destroy();
		this._signalsHandler.destroy();
		if (this._isPrimary) {
			Main.wm.removeKeybinding("shortcut-keybind");
		}
		this._disablePressureBarrier();
		if (this._isPrimary && this._searchEntryBin) {
			this._searchEntryBin.style = null;
		}

		if (this._isPrimary && this._oldEase) {
			MessageTray._bannerBin.ease = this._oldEase;
			this._oldEase = null;
		}
		this.show(0, "destroy");
		this._setUnredirectDisabled(false);

		// The shell disables this extension while the screen is locked. Giving
		// the top bar its strut back then shrinks the work area and pushes
		// floating windows down.
		Main.layoutManager.removeChrome(PanelBox);
		Main.layoutManager.addChrome(PanelBox, {
			affectsStruts: Main.sessionMode.currentMode !== 'unlock-dialog',
			trackFullscreen: true
		});
		this._desktopIconsUsableArea.destroy();
		this._desktopIconsUsableArea = null;
	}
};
