/**
 * This file is part of Hide Top Bar (Multi-Monitor)
 *
 * Fork of Hide Top Bar by Thomas Vogt, extended for multi-monitor support.
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import Clutter from 'gi://Clutter';
import GLib from 'gi://GLib';

import * as Intellihide from './intellihide.js';
import * as WindowVisibility from './windowVisibility.js';
import * as Convenience from './convenience.js';
import * as DesktopIconsIntegration from './desktopIconsIntegration.js';

const DEBUG = Convenience.DEBUG;
const MMDEBUG = Convenience.MMDEBUG;

/**
 * Lightweight visibility controller for a single secondary panel.
 *
 * Unlike the primary PanelVisibilityManager, this controller never touches
 * shell-global resources (MessageTray, hot corners, keybindings, overview,
 * pressure barriers, struts). It only:
 *   - owns a per-monitor detection strategy (overlap -> Intellihide, or
 *     visible-windows -> WindowVisibility),
 *   - slides its own box actor on/off its monitor to hide/show it.
 *
 * Phase 3A scope: automatic hide/show driven by the strategy, plus a plain
 * "force show" used while the overview is visible. Cursor-edge reveal and full
 * overview integration are deferred to phase 3B.
 */
export class SecondaryPanelVisibilityManager {
	/**
	 * @param {Gio.Settings} settings  shared extension settings
	 * @param {number} monitorIndex    monitor this controller manages
	 * @param {Clutter.Actor} boxActor the secondary panel box (chrome actor)
	 * @param {Clutter.Actor} panel    the secondary Panel.Panel actor
	 */
	constructor(settings, monitorIndex, boxActor, panel) {
		DEBUG("SecondaryPanelVisibilityManager(" + monitorIndex + ")");
		this._settings = settings;
		this._monitorIndex = monitorIndex;
		this._box = boxActor;
		this._panel = panel;

		this._animationActive = false;
		this._hidden = false;
		this._forcedVisible = false;
		this._pointerVisible = false;
		this._unredirectDisabled = false;
		this._destroyed = false;

		// Baseline on-screen Y of the box (its monitor's top edge).
		this._baseY = this._box.y;

		this._signalsHandler = new Convenience.GlobalSignalsHandler();

		// sb4edge: tell Desktop Icons NG to keep its icons below this secondary panel. Only the primary
		// controller reported a margin, and only for the primary monitor (-1), so on secondary monitors
		// the icons started under the panel. A separate ID per monitor, so the controllers do not
		// overwrite each other's margins.
		this._desktopIconsUsableArea = new DesktopIconsIntegration.DesktopIconsUsableAreaClass(
			'hidetopbar-multimonitor@linuxitos.local:secondary-' + monitorIndex);
		this._updateDesktopIconsMargin = () => {
			if (this._destroyed || !this._box || !this._desktopIconsUsableArea)
				return;
			this._desktopIconsUsableArea.resetMargins();
			this._desktopIconsUsableArea.setMargins(this._monitorIndex, Math.round(this._box.height), 0, 0, 0);
		};
		this._boxHeightId = this._box.connect('notify::height', this._updateDesktopIconsMargin);
		this._updateDesktopIconsMargin();

		this._strategy = null;
		this._buildStrategy();
		// Pointer tracking also works at internal monitor edges, where an
		// outer-screen pressure barrier cannot reliably detect pointer entry.
		// sb4edge (battery): driven by pointer motion (cursor tracker
		// 'position-invalidated', no events while the pointer is still) instead
		// of a 75 ms poll that woke the CPU 13 times a second per extra monitor.
		this._updatePointer = () => {
			if (this._destroyed || !this._box || !this._panel)
				return;
			const [x, y] = global.get_pointer();
			const height = this._panel.height || this._box.height;
			const insideX = x >= this._box.x && x < this._box.x + this._box.width;
			const menuOpen = !!this._panel.menuManager?.activeMenu;
			const enabled = this._settings.get_boolean('mouse-sensitive');
			const atEdge = insideX && y >= this._baseY && y <= this._baseY + 2;
			const inPanel = insideX && y >= this._baseY && y < this._baseY + height;
			const reveal = enabled && (atEdge || (this._pointerVisible && (inPanel || menuOpen)));
			if (reveal !== this._pointerVisible) {
				this._pointerVisible = reveal;
				this._applyStrategyDecision();
			}
			// While one of this panel's menus holds it open, re-check slowly so it
			// hides after the menu closes even if the pointer does not move.
			if (menuOpen && reveal && !this._menuCheckId) {
				this._menuCheckId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 500, () => {
					this._menuCheckId = 0;
					this._updatePointer();
					return GLib.SOURCE_REMOVE;
				});
			}
		};
		this._cursorTracker = global.backend.get_cursor_tracker();
		this._cursorMovedId = this._cursorTracker.connect('position-invalidated', this._updatePointer);
		this._updatePointer();

		// React to runtime changes of the hide-mode setting.
		this._signalsHandler.add([
			this._settings,
			'changed::multi-monitor-hide-mode',
			this._onHideModeChanged.bind(this),
		]);
	}

	_hideModeSetting() {
		return this._settings.get_string('multi-monitor-hide-mode');
	}

	_buildStrategy() {
		const mode = this._hideModeSetting();
		DEBUG("secondary[" + this._monitorIndex + "] strategy: " + mode);
		MMDEBUG("visibility[" + this._monitorIndex + "]: strategy=" + mode
			+ " baseY=" + this._baseY);

		if (mode === 'visible-windows') {
			this._strategy = new WindowVisibility.WindowVisibility(
				this._settings, this._monitorIndex,
			);
		} else {
			// 'overlap' (default): reuse the original intellihide algorithm,
			// filtered to this monitor.
			this._strategy = new Intellihide.Intellihide(
				this._settings, this._monitorIndex,
			);
		}

		this._strategyStatusId = this._strategy.connect(
			'status-changed', this._onStatusChanged.bind(this),
		);
		this._strategy.enable();

		// The overlap strategy needs a target box (the panel area). The
		// visible-windows strategy ignores it. Provide it once allocation is
		// known.
		this._updateTargetBox();

		// Apply an explicit initial decision so the panel starts in the correct
		// state even if the strategy's first check did not cross a threshold
		// (e.g. "no windows" stays at the default status and emits nothing).
		this._applyStrategyDecision();
	}

	_destroyStrategy() {
		if (this._strategy) {
			if (this._strategyStatusId) {
				this._strategy.disconnect(this._strategyStatusId);
				this._strategyStatusId = 0;
			}
			this._strategy.destroy();
			this._strategy = null;
		}
	}

	_onHideModeChanged() {
		if (this._destroyed)
			return;
		this._destroyStrategy();
		this._buildStrategy();
	}

	_updateTargetBox() {
		if (!this._strategy || !this._box)
			return;
		if (typeof this._strategy.updateTargetBox !== 'function')
			return;
		// Panel area in stage coordinates: the box occupies the top strip of
		// its monitor.
		const box = new Clutter.ActorBox();
		box.init_rect(
			this._box.x,
			this._baseY,
			this._box.width,
			this._panel?.height || this._box.height,
		);
		this._strategy.updateTargetBox(box);
	}

	_onStatusChanged() {
		if (this._destroyed)
			return;
		// While forced visible (overview), defer the strategy's decision; it is
		// re-applied when the force is released.
		if (this._forcedVisible)
			return;
		this._applyStrategyDecision();
	}

	_applyStrategyDecision() {
		const shouldHide = !this._forcedVisible && !this._pointerVisible
			&& this._strategy?.getOverlapStatus();
		MMDEBUG("visibility[" + this._monitorIndex + "]: decision shouldHide="
			+ shouldHide);
		if (shouldHide)
			this.hide();
		else
			this.show();
	}

	_setUnredirectDisabled(disabled) {
		if (disabled === this._unredirectDisabled) return;
		if (disabled) global.compositor.disable_unredirect();
		else global.compositor.enable_unredirect();
		this._unredirectDisabled = disabled;
	}

	_animTime() {
		return this._settings.get_double('animation-time-autohide');
	}

	hide(immediate = false) {
		if (this._destroyed || !this._box)
			return;
		if (this._hidden && !this._animationActive)
			return;

		const delta = -(this._panel?.height || this._box.height);
		this._hidden = true;

		if (this._animationActive) {
			this._box.remove_all_transitions();
			this._animationActive = false;
		}

		if (immediate) {
			this._box.y = this._baseY + delta;
			this._setUnredirectDisabled(false);
			return;
		}

		this._animationActive = true;
		this._box.ease({
			y: this._baseY + delta,
			duration: this._animTime() * 1000,
			mode: Clutter.AnimationMode.EASE_OUT_QUAD,
			onComplete: () => {
				this._animationActive = false;
				if (this._hidden) this._setUnredirectDisabled(false);
			},
		});
	}

	show(immediate = false) {
		if (this._destroyed || !this._box)
			return;
		if (!this._hidden && !this._animationActive && this._box.y === this._baseY)
			return;

		this._hidden = false;
		this._setUnredirectDisabled(true);

		if (this._animationActive) {
			this._box.remove_all_transitions();
			this._animationActive = false;
		}

		if (immediate) {
			this._box.y = this._baseY;
			return;
		}

		this._animationActive = true;
		this._box.ease({
			y: this._baseY,
			duration: this._animTime() * 1000,
			mode: Clutter.AnimationMode.EASE_OUT_QUAD,
			onComplete: () => {
				this._animationActive = false;
			},
		});
	}

	/**
	 * Force the panel visible regardless of the strategy (used by the overview
	 * coordinator in phase 3B). When released, the strategy decision is
	 * re-applied.
	 */
	setForcedVisible(forced) {
		if (this._destroyed)
			return;
		this._forcedVisible = forced;
		if (forced)
			this.show();
		else
			this._applyStrategyDecision();
	}

	/**
	 * Recompute the baseline Y and target box after a geometry change. Called
	 * by the owner when the monitor layout changes.
	 */
	refreshGeometry() {
		if (this._destroyed || !this._box)
			return;
		this._baseY = this._box.y + (this._hidden ? (this._panel.height || this._box.height) : 0);
		this._updateTargetBox();
		// Reassert current state so the box is at the right offset.
		if (this._hidden)
			this.hide(true);
		else
			this.show(true);
	}

	destroy() {
		DEBUG("SecondaryPanelVisibilityManager.destroy(" + this._monitorIndex + ")");
		MMDEBUG("visibility[" + this._monitorIndex + "]: destroy");
		this._destroyed = true;
		if (this._cursorMovedId) {
			this._cursorTracker.disconnect(this._cursorMovedId);
			this._cursorMovedId = 0;
		}
		if (this._menuCheckId) {
			GLib.Source.remove(this._menuCheckId);
			this._menuCheckId = 0;
		}
		this._setUnredirectDisabled(false);

		if (this._box && this._animationActive) {
			this._box.remove_all_transitions();
			this._animationActive = false;
		}

		this._signalsHandler.destroy();
		this._signalsHandler = null;

		if (this._box && this._boxHeightId) {
			this._box.disconnect(this._boxHeightId);
			this._boxHeightId = 0;
		}
		if (this._desktopIconsUsableArea) {
			this._desktopIconsUsableArea.destroy();
			this._desktopIconsUsableArea = null;
		}

		this._destroyStrategy();

		this._box = null;
		this._panel = null;
		this._settings = null;
	}
}
