// One shared patch of GNOME's Panel class for the features that need every top bar, including the extra top bars
// that multi-monitor extensions (Hide Top Bar (Multi-Monitor)) build as further Panel.Panel instances.
// Features subscribe; Panel.prototype is patched while at least one subscriber exists and restored after the last.
// A single owner avoids the restore-order problem of two independent overrides of the same method.
//
// Subscriber hooks (all optional):
//   beforeInit(panel), afterInit(panel)   around Panel._init, for extra panels only (the primary panel is built
//                                         before any extension runs)
//   afterUpdate(panel)                    after Panel._updatePanel (session mode changes re-show indicators)
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as Panel from 'resource:///org/gnome/shell/ui/panel.js';

const proto = Panel.Panel.prototype;
const subscribers = new Set();
let patched = null;   // {name: [original, wrapper]} while patched

function call(hook, panel) {
    for (const s of subscribers) {
        try {
            s[hook]?.(panel);
        } catch (e) {
            console.error(`[sb4edge-tweaks-xr] panel hook ${hook}: ${e.message}`);
        }
    }
}

function patch() {
    // Each wrapper captures its own original, so a wrapper left in place by unpatch() keeps working.
    const init = proto._init;
    const update = proto._updatePanel;
    const initWrapper = function (...args) {
        const extra = !!Main.panel && this !== Main.panel;
        if (extra)
            call('beforeInit', this);
        try {
            return init.apply(this, args);
        } finally {
            if (extra)
                call('afterInit', this);
        }
    };
    const updateWrapper = function (...args) {
        const result = update.apply(this, args);
        call('afterUpdate', this);
        return result;
    };
    proto._init = initWrapper;
    proto._updatePanel = updateWrapper;
    patched = {_init: [init, initWrapper], _updatePanel: [update, updateWrapper]};
}

function unpatch() {
    // Restore only methods that still hold our wrapper. If another extension wrapped it meanwhile (Top Bar
    // Organizer patches this prototype too), restoring would drop that extension's wrapper; ours then stays in
    // place and, with no subscribers, only calls the original.
    for (const [name, [original, wrapper]] of Object.entries(patched)) {
        if (proto[name] === wrapper)
            proto[name] = original;
    }
    patched = null;
}

export function subscribe(subscriber) {
    if (!subscribers.size)
        patch();
    subscribers.add(subscriber);
}

export function unsubscribe(subscriber) {
    if (!subscribers.delete(subscriber))
        return;
    if (!subscribers.size)
        unpatch();
}

// Every Panel.Panel currently on the stage (the primary one first).
export function allPanels() {
    const found = [];
    const walk = actor => {
        if (actor instanceof Panel.Panel) {
            found.push(actor);
            return;
        }
        for (const child of actor.get_children())
            walk(child);
    };
    walk(global.stage);
    return [Main.panel, ...found.filter(p => p !== Main.panel)];
}
