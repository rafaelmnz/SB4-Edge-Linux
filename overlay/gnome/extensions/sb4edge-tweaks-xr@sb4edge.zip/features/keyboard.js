// Keyboard status: GNOME's own OSD when Caps Lock or Num Lock changes (it never takes keyboard focus), and the
// active locks in every top bar. Derived from Keyboard Informer (kbd-informer@digitalspace.name) by Tomáš Mark,
// GPL-3.0-or-later. Changes: follows the keymap's state-changed signal instead of polling the pointer every
// 200 ms; held modifiers (no signal exists for them) are opt-in and polled only while that option is on; shown on
// the extra top bars of multi-monitor extensions too; fixed symbols instead of a symbol editor; no Scroll Lock.
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import St from 'gi://St';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import * as PanelHooks from './panelHooks.js';

const CAPS_ICON = new Gio.ThemedIcon({names: ['caps-lock-symbolic', 'input-keyboard-symbolic']});
const NUM_ICON = new Gio.ThemedIcon({names: ['input-dialpad-symbolic', 'input-keyboard-symbolic']});
const MODIFIERS = [
    [Clutter.ModifierType.SHIFT_MASK, '⇧'],
    [Clutter.ModifierType.CONTROL_MASK, '⌃'],
    [Clutter.ModifierType.MOD1_MASK, '⌥'],
    [Clutter.ModifierType.MOD4_MASK, '❖'],
];
const MODIFIER_MASK = MODIFIERS.reduce((all, [mask]) => all | mask, 0);
const POLL_MS = 200;

export class KeyboardStatus {
    constructor(extension, settings) {
        this._settings = settings;
    }

    enable() {
        this._keymap = global.stage.context.get_backend().get_default_seat().get_keymap();
        this._caps = this._keymap.get_caps_lock_state();
        this._num = this._keymap.get_num_lock_state();
        this._mods = 0;
        this._pollId = 0;
        this._indicators = new Map();   // panel -> St.Bin

        this._keymap.connectObject('state-changed', () => this._onLocksChanged(), this);
        this._settings.connectObject(
            'changed::keyboard-panel-locks', () => this._syncPanels(),
            'changed::keyboard-panel-modifiers', () => this._syncPolling(),
            this);
        PanelHooks.subscribe(this);
        for (const panel of PanelHooks.allPanels())
            this._addIndicator(panel);
        this._syncPolling();
    }

    disable() {
        this._stopPolling();
        PanelHooks.unsubscribe(this);
        this._settings.disconnectObject(this);
        this._keymap.disconnectObject(this);
        const indicators = [...this._indicators.values()];
        this._indicators = null;
        for (const bin of indicators)
            bin.destroy();
        this._keymap = null;
    }

    // An extra top bar was built (multi-monitor extension)
    afterInit(panel) {
        this._addIndicator(panel);
        this._syncPanels();
    }

    _addIndicator(panel) {
        if (this._indicators.has(panel) || !panel._rightBox)
            return;
        const bin = new St.Bin({
            style_class: 'panel-button',
            reactive: false,
            can_focus: false,
            y_align: Clutter.ActorAlign.CENTER,
            visible: false,
            child: new St.Label({style_class: 'panel-status-menu-label', y_align: Clutter.ActorAlign.CENTER}),
        });
        panel._rightBox.insert_child_at_index(bin, 0);
        this._indicators.set(panel, bin);
        // Destroyed together with an extra top bar
        bin.connect('destroy', () => this._indicators?.delete(panel));
    }

    _onLocksChanged() {
        const caps = this._keymap.get_caps_lock_state();
        const num = this._keymap.get_num_lock_state();
        if (caps === this._caps && num === this._num)
            return;
        if (this._settings.get_boolean('keyboard-osd')) {
            if (caps !== this._caps)
                Main.osdWindowManager.showAll(CAPS_ICON, caps ? 'Caps Lock on' : 'Caps Lock off');
            else
                Main.osdWindowManager.showAll(NUM_ICON, num ? 'Num Lock on' : 'Num Lock off');
        }
        this._caps = caps;
        this._num = num;
        this._syncPanels();
    }

    _syncPolling() {
        this._stopPolling();
        this._mods = 0;
        if (this._settings.get_boolean('keyboard-panel-modifiers')) {
            this._pollId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, POLL_MS, () => {
                const mods = global.get_pointer()[2] & MODIFIER_MASK;
                if (mods !== this._mods) {
                    this._mods = mods;
                    this._syncPanels();
                }
                return GLib.SOURCE_CONTINUE;
            });
        }
        this._syncPanels();
    }

    _stopPolling() {
        if (this._pollId)
            GLib.source_remove(this._pollId);
        this._pollId = 0;
    }

    _syncPanels() {
        const parts = [];
        if (this._settings.get_boolean('keyboard-panel-locks')) {
            if (this._caps)
                parts.push('Caps');
            if (this._num)
                parts.push('Num');
        }
        for (const [mask, symbol] of MODIFIERS) {
            if (this._mods & mask)
                parts.push(symbol);
        }
        const text = parts.join(' ');
        for (const bin of this._indicators.values()) {
            bin.child.text = text;
            bin.visible = text !== '';
        }
    }
}
