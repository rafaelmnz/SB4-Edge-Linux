// Accessibility menu: GNOME shows it whenever any accessibility feature is on (Large Text counts any text size
// above 100 %), ignoring "Always Show Accessibility Menu". Here it follows that setting alone, on every top bar:
// the extra top bars of multi-monitor extensions have their own accessibility menu, and a session mode change
// (unlock) re-shows the item. Replaces Hide Accessibility Menu (hideaccessibilitymenu@boni.scot), which only hid the
// primary panel's icon and lost it on a session update.
import Gio from 'gi://Gio';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

import * as PanelHooks from './panelHooks.js';

const A11Y_SCHEMA = 'org.gnome.desktop.a11y';
const ALWAYS_SHOW = 'always-show-universal-access-status';

export class AccessibilityMenu {
    enable() {
        this._a11y = new Gio.Settings({schema_id: A11Y_SCHEMA});
        this._a11y.connectObject(`changed::${ALWAYS_SHOW}`, () => this._syncAll(), this);
        // The primary panel bound its own _updatePanel to session-mode 'updated' before any extension ran, so the
        // afterUpdate hook only reaches panels built later; this handler (connected after it) covers it.
        Main.sessionMode.connectObject('updated', () => this._syncAll(), this);
        PanelHooks.subscribe(this);
        this._syncAll();
    }

    disable() {
        PanelHooks.unsubscribe(this);
        Main.sessionMode.disconnectObject(this);
        this._a11y.disconnectObject(this);
        this._a11y = null;
        for (const panel of PanelHooks.allPanels())
            panel.statusArea?.a11y?.container.show();
    }

    afterInit(panel) {
        this._sync(panel);
    }

    afterUpdate(panel) {
        this._sync(panel);
    }

    _syncAll() {
        for (const panel of PanelHooks.allPanels())
            this._sync(panel);
    }

    // The item itself still decides its own visibility when shown; we only hide its container.
    _sync(panel) {
        const container = panel.statusArea?.a11y?.container;
        if (!container || !this._a11y)
            return;
        if (this._a11y.get_boolean(ALWAYS_SHOW))
            container.show();
        else
            container.hide();
    }
}
