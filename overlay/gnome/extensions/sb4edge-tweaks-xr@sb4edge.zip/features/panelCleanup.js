// Extra top bars: clean up after them when they are destroyed.
//
// Multi-monitor extensions (Hide Top Bar (Multi-Monitor)) build a full Panel.Panel per extra monitor, and destroy
// and rebuild it on every monitor change and at every lock (extensions are disabled while locked). GNOME's own top
// bar items assume they live forever: the date menu, Bluetooth, Thunderbolt, background apps, menus and others
// connect to session-wide objects (session mode, Bluetooth / NetworkManager clients, settings, ...) and never
// disconnect. Each rebuild left those handlers behind, so later events (unlock, a Bluetooth change) ran code on
// destroyed items: "already disposed" errors, and work and memory that grew with every rebuild.
//
// This records the connections GNOME Shell's own code makes while an extra panel is built - synchronously in
// Panel._init, and in the quick settings' asynchronous _setupIndicators() that continues after it - to objects
// that outlive the panel, and disconnects those still connected once the panel is destroyed.
import Clutter from 'gi://Clutter';
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import GObject from 'gi://GObject';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import {EventEmitter} from 'resource:///org/gnome/shell/misc/signals.js';

import * as PanelHooks from './panelHooks.js';

// Frames skipped when deciding who made a connection: this extension's hook code and the signal plumbing.
const PLUMBING = /features\/panel(Cleanup|Hooks)\.js|misc\/signalTracker\.js|misc\/signals\.js|resource:\/\/\/org\/gnome\/gjs\/|^\s*$/;
const SHELL = 'resource:///org/gnome/shell/';
const ASYNC_SETUP = '_setupIndicators@resource:///org/gnome/shell/ui/panel.js';

// Session-wide actors that have been destroyed (only happens at shell shutdown). Module-level and watched for the
// actor's lifetime, so cleanups still pending after a disable (GNOME disables extensions before it destroys them)
// skip them too. One destroy handler per actor, ever.
const dead = new WeakSet();
const watched = new WeakSet();

function isConnected(obj, id) {
    if (obj instanceof GObject.Object)
        return GObject.signal_handler_is_connected(obj, id);
    return obj.signalHandlerIsConnected?.(id) ?? false;
}

// Records are [obj, id] for connect(), or [obj, owner, true] for connectObject(): those are removed through
// disconnectObject(owner), so GNOME's signal tracker stays consistent (removing them by id made it throw "No
// signal connection found" when the owner was destroyed later).
function release([obj, idOrOwner, tracked], dead) {
    if (dead.has(obj))
        return false;   // a session-wide actor destroyed meanwhile (shell shutdown): nothing left to remove
    if (tracked) {
        obj.disconnectObject(idOrOwner);
        return true;
    }
    if (!isConnected(obj, idOrOwner))
        return false;
    obj.disconnect(idOrOwner);
    return true;
}

export class PanelCleanup {
    enable() {
        this._sync = null;          // records of the panel whose _init is running
        this._async = [];           // [records] of extra panels whose quick settings are still being set up
        this._wrapCount = 0;
        this._wrapped = [];
        this._patchQuickSettings();
        PanelHooks.subscribe(this);
    }

    disable() {
        PanelHooks.unsubscribe(this);
        if (this._qsProto && this._qsProto._setupIndicators === this._qsWrapper)
            this._qsProto._setupIndicators = this._qsOriginal;
        this._qsProto = this._qsOriginal = this._qsWrapper = null;
        this._wrapCount = 0;
        this._unwrapConnect();
        this._sync = null;
        this._async = [];
        // Pending cleanups (idle callbacks) are left to run: at lock GNOME disables extensions in reverse order,
        // so a multi-monitor extension listed after this one destroys its top bars just before this disable().
    }

    beforeInit(_panel) {
        this._session = null;
        this._sync = [];
        this._pendingRecords = this._sync;   // the quick settings' async setup of this panel adds to the same list
        this._wrapConnect();
    }

    afterInit(panel) {
        const records = this._sync;
        this._sync = null;
        this._pendingRecords = null;
        this._unwrapConnectOnce();
        if (!records)
            return;
        panel.connect('destroy', () => {
            // After the destroy has finished (and any async setup has added its records), so the items' own
            // cleanup runs first and only what is still connected is removed.
            GLib.idle_add(GLib.PRIORITY_DEFAULT_IDLE, () => {
                let removed = 0;
                for (const record of records) {
                    try {
                        if (release(record, dead))
                            removed++;
                    } catch {}
                }
                records.length = 0;
                if (removed)
                    console.debug(`[sb4edge-tweaks-xr] extra top bar destroyed: removed ${removed} leftover connections`);
                return GLib.SOURCE_REMOVE;
            });
        });
    }

    // QuickSettings (not exported) builds its indicators in an async method started by its constructor; wrap it on
    // the class prototype so the part after its first await is attributed to the extra panel too.
    _patchQuickSettings() {
        const qs = Main.panel.statusArea.quickSettings;
        const proto = qs && Object.getPrototypeOf(qs);
        if (!proto?._setupIndicators)
            return;
        const self = this;
        this._qsProto = proto;
        this._qsOriginal = proto._setupIndicators;
        const original = this._qsOriginal;
        this._qsWrapper = function (...args) {
            const records = self._pendingRecords;
            if (!records)   // the primary panel, or nobody to attribute to
                return original.apply(this, args);
            self._async.push(records);
            self._wrapConnect();
            const done = () => {
                const i = self._async.indexOf(records);
                if (i >= 0)
                    self._async.splice(i, 1);
                self._unwrapConnectOnce();
            };
            const promise = original.apply(this, args);
            promise.then(done, done);
            return promise;
        };
        proto._setupIndicators = this._qsWrapper;
    }

    // Who should own a connection being made now: the panel being built (a synchronous call from GNOME Shell code)
    // or the panel whose quick settings are being set up (a call from inside _setupIndicators). Connections made
    // by other extensions from inside these windows (Top Bar Organizer's panel hook) are left alone.
    _owner(stack) {
        const frames = stack.split('\n').slice(1);
        const first = frames.find(f => !PLUMBING.test(f));
        if (!first || !first.includes(SHELL))
            return null;
        if (this._async.length && frames.some(f => f.includes(ASYNC_SETUP)))
            return this._async[this._async.length - 1];
        return this._sync;
    }

    // Keep only objects that outlive the panel: non-actor objects, and session-wide actors (the ones GNOME's main.js
    // exports, such as the message tray, and the layout manager's groups). Other actors (the panel's own, its menus
    // in the UI group) are destroyed with it. Gio.Settings and D-Bus proxies of the items are disposed by them on
    // destroy (run_dispose drops every handler); touching them afterwards is an error, and nothing is left there.
    _external(obj) {
        if (obj instanceof Gio.Settings || obj instanceof Gio.DBusProxy)
            return false;
        if (!(obj instanceof Clutter.Actor))
            return true;
        return this._sessionActors().has(obj);
    }

    // Built per extra panel (cheap: a few dozen properties), as some of them are created lazily.
    _sessionActors() {
        if (!this._session) {
            const actors = [global.stage, global.window_group, global.top_window_group,
                ...Object.values(Main), ...Object.values(Main.layoutManager)];
            this._session = new Set(actors.filter(a => a instanceof Clutter.Actor));
            for (const actor of this._session) {
                if (!watched.has(actor)) {
                    watched.add(actor);
                    actor.connect('destroy', () => dead.add(actor));
                }
            }
        }
        return this._session;
    }

    _record(obj, id) {
        if (typeof id !== 'number' || id <= 0 || !this._external(obj))
            return;
        const stack = new Error().stack;
        if (stack.includes('misc/signalTracker.js'))
            return;   // made by connectObject(), recorded there with its owner
        this._owner(stack)?.push([obj, id]);
    }

    _recordTracked(obj, args) {
        const owner = args[args.length - 1];
        if (!owner || typeof owner !== 'object' || !this._external(obj))
            return;
        this._owner(new Error().stack)?.push([obj, owner, true]);
    }

    _wrapConnect() {
        if (this._wrapCount++)
            return;
        const self = this;
        const wrap = (target, name) => {
            const original = target[name];
            const wrapper = function (...args) {
                const id = original.apply(this, args);
                self._record(this, id);
                return id;
            };
            target[name] = wrapper;
            this._wrapped.push([target, name, original, wrapper]);
        };
        wrap(GObject.Object.prototype, 'connect');
        wrap(GObject.Object.prototype, 'connect_after');
        wrap(EventEmitter.prototype, 'connect');
        const wrapTracked = target => {
            const original = target.connectObject;
            if (!original)
                return;
            const wrapper = function (...args) {
                const result = original.apply(this, args);
                self._recordTracked(this, args);
                return result;
            };
            target.connectObject = wrapper;
            this._wrapped.push([target, 'connectObject', original, wrapper]);
        };
        wrapTracked(GObject.Object.prototype);
        wrapTracked(EventEmitter.prototype);
    }

    _unwrapConnectOnce() {
        if (this._wrapCount > 0 && --this._wrapCount === 0)
            this._unwrapConnect();
    }

    _unwrapConnect() {
        for (const [target, name, original, wrapper] of this._wrapped.splice(0).reverse()) {
            if (target[name] === wrapper)
                target[name] = original;
        }
    }
}
