// Screenshot: derived from No Screenshot Box (https://github.com/abdallah-alkanani/no-screenshot-box, GPL-3.0).
// Clears the screenshot UI's initial pre-selected area, captures when the selection drag ends, captures a window
// on click, hides the desktop in window mode, always opens in area mode, and can mute only the capture sound.

import GLib from 'gi://GLib';
import Gio from 'gi://Gio';
import Meta from 'gi://Meta';
import St from 'gi://St';
import {InjectionManager} from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

const LOG_PREFIX = 'NoScreenshotBox';
const SCREEN_CAPTURE_SOUND = 'screen-capture';
const DEBUG_ENABLED = (() => {
    const debugEnv = GLib.getenv('G_MESSAGES_DEBUG') ?? '';

    return GLib.getenv('NO_SCREENSHOT_BOX_DEBUG') === '1' ||
        debugEnv === 'all' ||
        debugEnv.split(':').includes(LOG_PREFIX);
})();

class NoScreenshotBoxController {
    constructor(settings) {
        this._settings = settings;
        this._removePreselectedBox = true;
        this._screenshotOnRelease = true;
        this._muteScreenshotSound = false;
        this._injectionManager = null;
        this._windowSelectorProto = null;
        this._areaSelector = null;
        this._retryId = 0;
        this._selectionRectOpacity = null;
        this._handleOpacities = null;
        this._attemptCount = 0;
        this._capturing = false;
    }

    enable() {
        this._attemptCount = 0;
        this._capturing = false;
        this._handleOpacities = new Map();
        this._injectionManager = new InjectionManager();

        this._settings?.disconnectObject(this);
        this._refreshRemovePreselectedBox();
        this._refreshScreenshotOnRelease();
        this._refreshMuteScreenshotSound();
        this._settings?.connectObject(
            'changed::remove-preselected-box',
            () => {
                this._refreshRemovePreselectedBox();
                if (this._areaSelector)
                    this._applyPatch(this._areaSelector);
            },
            this);
        this._settings?.connectObject(
            'changed::screenshot-on-release',
            () => this._refreshScreenshotOnRelease(),
            this);
        this._settings?.connectObject(
            'changed::mute-screenshot-sound',
            () => this._refreshMuteScreenshotSound(),
            this);

        this._patchSoundPlayer();
        this._patchOpen();
        this._patchWindowSelector();
        this._patchWhenReady();
    }

    disable() {
        if (this._retryId) {
            GLib.source_remove(this._retryId);
            this._retryId = 0;
        }

        this._restore();
        this._injectionManager?.clear();
        this._settings?.disconnectObject(this);

        this._injectionManager = null;
        this._windowSelectorProto = null;
        this._handleOpacities = null;
        this._selectionRectOpacity = null;
        this._capturing = false;
    }

    _log(message) {
        if (!DEBUG_ENABLED)
            return;

        console.debug(`${LOG_PREFIX}: ${message}`);
    }

    _refreshScreenshotOnRelease() {
        this._screenshotOnRelease = this._settings?.get_boolean('screenshot-on-release') ?? true;
    }

    _refreshRemovePreselectedBox() {
        this._removePreselectedBox = this._settings?.get_boolean('remove-preselected-box') ?? true;
    }

    _refreshMuteScreenshotSound() {
        this._muteScreenshotSound =
            this._settings?.get_boolean('mute-screenshot-sound') ?? false;
    }

    _patchSoundPlayer() {
        const soundPlayer = global.display.get_sound_player();

        if (!soundPlayer || !this._injectionManager) {
            this._log('Unable to find the screenshot sound player');
            return;
        }

        // GNOME Shell 45-50 play the capture sound by theme name, 51 by file.
        const captureSoundPath = `${global.datadir}/sounds/${SCREEN_CAPTURE_SOUND}.oga`;
        this._muteCaptureSound(soundPlayer, 'play_from_theme',
            name => name === SCREEN_CAPTURE_SOUND);
        this._muteCaptureSound(soundPlayer, 'play_from_file',
            file => file.get_path() === captureSoundPath);
    }

    _muteCaptureSound(soundPlayer, methodName, isCaptureSound) {
        this._injectionManager.overrideMethod(
            soundPlayer,
            methodName,
            originalMethod => {
                const play = originalMethod.bind(soundPlayer);

                return (sound, ...args) => {
                    if (this._muteScreenshotSound && isCaptureSound(sound))
                        return;

                    play(sound, ...args);
                };
            });
    }

    _patchOpen() {
        const screenshotUI = Main?.screenshotUI;
        if (!screenshotUI || !this._injectionManager)
            return;

        const settings = this._settings;
        // GNOME reopens in the last used mode (e.g. Window). Start dimmed with
        // the area selector instead, unless a screencast-only request asks otherwise.
        this._injectionManager.overrideMethod(screenshotUI, 'open', originalOpen => {
            return function (...args) {
                if (!this.visible && settings?.get_boolean('start-in-area-mode') &&
                    this._selectionButton && !this._selectionButton.checked)
                    this._selectionButton.checked = true;
                return originalOpen.apply(this, args);
            };
        });
    }

    _patchWindowSelector() {
        const selector = Main?.screenshotUI?._windowSelectors?.[0];
        if (!selector || !this._injectionManager) {
            this._log('No window selector found; window tweaks inactive');
            return;
        }

        // UIWindowSelector is not exported; patch its prototype through an instance
        // so selectors recreated on monitor changes are covered too.
        const proto = Object.getPrototypeOf(selector);
        this._windowSelectorProto = proto;
        const controller = this;
        this._injectionManager.overrideMethod(proto, 'capture', originalCapture => {
            return function (...args) {
                const hideDesktop = controller._settings?.get_boolean('hide-desktop-window') ?? true;
                if (hideDesktop) {
                    // capture() lists global.get_window_actors(); shadow it for this call only.
                    const allActors = global.get_window_actors.bind(global);
                    global.get_window_actors = () =>
                        allActors().filter(a => !controller._isDesktopWindow(a.metaWindow));
                    try {
                        originalCapture.apply(this, args);
                    } finally {
                        delete global.get_window_actors;
                    }
                } else {
                    originalCapture.apply(this, args);
                }

                for (const win of this.windows())
                    win.connect('clicked', () => controller._autoCaptureWindow(win));
            };
        });
    }

    _isDesktopWindow(metaWindow) {
        if (!metaWindow)
            return false;
        if (metaWindow.get_window_type() === Meta.WindowType.DESKTOP)
            return true;
        // Desktop Icons NG (ding) draws the desktop in a normal toplevel window.
        if (metaWindow.customJS_ding)
            return true;
        const ids = [metaWindow.get_gtk_application_id?.(), metaWindow.get_wm_class?.()];
        return ids.some(id => id === 'com.rastersoft.ding');
    }

    async _autoCaptureWindow(win) {
        if (!(this._settings?.get_boolean('capture-window-on-click') ?? true))
            return;

        const screenshotUI = Main?.screenshotUI;
        if (!screenshotUI?._windowButton?.checked || !screenshotUI._shotButton?.checked)
            return;
        if (!win.checked || this._capturing)
            return;

        this._capturing = true;
        try {
            await screenshotUI._onCaptureButtonClicked();
        } catch (error) {
            this._log(`Window auto capture failed: ${error}`);
        } finally {
            this._capturing = false;
        }
    }

    _patchWhenReady() {
        const maxAttempts = 20;
        const attempt = () => {
            this._attemptCount++;

            const areaSelector = this._getAreaSelector();
            if (!areaSelector) {
                if (this._attemptCount === 1)
                    this._log('Screenshot UI not ready; will retry shortly');

                if (this._attemptCount >= maxAttempts) {
                    this._log('Unable to find screenshot selection actor; extension will stay inactive');
                    return true;
                }

                return false;
            }

            this._applyPatch(areaSelector);
            return true;
        };

        if (attempt())
            return;

        this._retryId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, 500, () => {
            if (attempt()) {
                this._retryId = 0;
                return GLib.SOURCE_REMOVE;
            }

            return GLib.SOURCE_CONTINUE;
        });
    }

    _applyPatch(areaSelector) {
        this._restore();
        this._areaSelector = areaSelector;

        if (this._removePreselectedBox && areaSelector.reset && this._injectionManager) {
            this._injectionManager.overrideMethod(areaSelector, 'reset', originalReset => (...args) => {
                const result = originalReset?.apply(areaSelector, args);
                this._clearSelection(areaSelector);
                return result;
            });
        } else if (this._removePreselectedBox) {
            this._log('Area selector has no reset(); clearing selection directly');
        }

        if (this._removePreselectedBox) {
            // Show the rectangle only after the user actively starts a drag.
            areaSelector.connectObject('drag-started',
                () => this._revealSelection(areaSelector),
                this);
        }
        areaSelector.connectObject('drag-ended',
            () => this._autoCapture(areaSelector),
            this);

        if (this._removePreselectedBox)
            this._clearSelection(areaSelector);
        this._log('Patched screenshot selection reset');
    }

    _restore() {
        if (!this._areaSelector)
            return;

        const areaSelector = this._areaSelector;

        this._injectionManager?.restoreMethod(areaSelector, 'reset');
        areaSelector.disconnectObject(this);

        const selectionRect = this._getSelectionRect(areaSelector);
        if (selectionRect && this._selectionRectOpacity !== null)
            selectionRect.opacity = this._selectionRectOpacity;
        this._selectionRectOpacity = null;

        if (this._handleOpacities) {
            for (const [name, actor] of this._getHandles(areaSelector)) {
                const original = this._handleOpacities.get(name);
                if (actor && original !== undefined)
                    actor.opacity = original;
            }
            this._handleOpacities.clear();
        }

        this._areaSelector = null;
    }

    _getAreaSelector() {
        return Main?.screenshotUI?._areaSelector ?? null;
    }

    _clearSelection(areaSelector) {
        if ('_startX' in areaSelector)
            areaSelector._startX = 0;
        if ('_startY' in areaSelector)
            areaSelector._startY = 0;
        if ('_lastX' in areaSelector)
            areaSelector._lastX = 0;
        if ('_lastY' in areaSelector)
            areaSelector._lastY = 0;

        areaSelector._updateSelectionRect?.();

        if (!this._handleOpacities)
            this._handleOpacities = new Map();

        for (const [name, actor] of this._getHandles(areaSelector)) {
            if (!actor)
                continue;

            if (!this._handleOpacities.has(name))
                this._handleOpacities.set(name, actor.opacity);

            actor.opacity = 0;
        }

        const selectionRect = this._getSelectionRect(areaSelector);
        if (selectionRect) {
            if (this._selectionRectOpacity === null)
                this._selectionRectOpacity = selectionRect.opacity;

            selectionRect.opacity = 0;
        }
    }

    _revealSelection(areaSelector) {
        const selectionRect = this._getSelectionRect(areaSelector);
        if (selectionRect && this._selectionRectOpacity !== null)
            selectionRect.opacity = this._selectionRectOpacity;

        // Keep handles hidden for a cleaner outline.
        for (const [, actor] of this._getHandles(areaSelector)) {
            if (actor)
                actor.opacity = 0;
        }
    }

    _getSelectionRect(areaSelector) {
        if (areaSelector._selectionRect)
            return areaSelector._selectionRect;

        if (areaSelector._areaIndicator?.['_selectionRect'])
            return areaSelector._areaIndicator._selectionRect;

        return null;
    }

    _getHandles(areaSelector) {
        const names = [
            '_topLeftHandle',
            '_topRightHandle',
            '_bottomLeftHandle',
            '_bottomRightHandle',
        ];

        return names.map(name => [name, areaSelector[name]]);
    }

    async _autoCapture(areaSelector) {
        // Trigger capture when a selection drag finishes in area mode.
        if (!this._screenshotOnRelease)
            return;

        const screenshotUI = Main?.screenshotUI;
        if (!screenshotUI)
            return;

        if (!screenshotUI._selectionButton?.checked)
            return;

        if (!screenshotUI._shotButton?.checked)
            return;

        const [,, w, h] = areaSelector.getGeometry?.() ?? [0, 0, 0, 0];
        if (w <= 2 || h <= 2)
            return;

        if (this._capturing)
            return;
        this._capturing = true;

        try {
            // Go through the capture button handler (not _saveScreenshot) so
            // extensions that hook it, such as OCR modes, get the capture.
            if (screenshotUI._onCaptureButtonClicked)
                await screenshotUI._onCaptureButtonClicked();
        } catch (error) {
            this._log(`Auto capture failed: ${error}`);
        } finally {
            this._capturing = false;
        }
    }
}

// The selection outline / handle styling, loaded only while this feature is on. A theme change (Main.loadTheme)
// installs a new St.Theme, so load it into each new theme. Listen to notify::theme, not 'changed': loading a
// stylesheet itself emits 'changed', which would recurse.
class Stylesheet {
    constructor(file) {
        this._file = file;
        this._context = St.ThemeContext.get_for_stage(global.stage);
        this._theme = null;
    }

    load() {
        this._loadInto(this._context.get_theme());
        this._context.connectObject('notify::theme', () => this._loadInto(this._context.get_theme()), this);
    }

    unload() {
        this._context.disconnectObject(this);
        this._theme?.unload_stylesheet(this._file);
        this._theme = null;
    }

    _loadInto(theme) {
        if (!theme || theme === this._theme)
            return;
        this._theme?.unload_stylesheet(this._file);
        theme.load_stylesheet(this._file);
        this._theme = theme;
    }
}

export class ScreenshotTweaks {
    constructor(extension, settings) {
        this._controller = new NoScreenshotBoxController(settings);
        this._stylesheet = new Stylesheet(extension.dir.resolve_relative_path('features/screenshot.css'));
    }

    enable() {
        this._stylesheet.load();
        this._controller.enable();
    }

    disable() {
        this._controller.disable();
        this._stylesheet.unload();
    }
}
