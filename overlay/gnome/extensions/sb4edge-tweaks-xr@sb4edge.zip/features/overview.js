// Overview: make Esc and a click on empty space close the overview / app grid; a click on a neighbouring
// workspace switches to it. On this system the stock handling
// (SearchController's stage key controller, the workspaces' click gesture) never acted on them, although the events
// reached the stage with only the overview's own modal grab (verified with a diagnostics extension).
import Clutter from 'gi://Clutter';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';

// Things a click on must NOT close the overview: windows, icons, buttons, the dash, search, thumbnails, entries.
const INTERACTIVE = /WindowPreview|AppIcon|FolderIcon|AppFolderDialog|Button|Dash|Search|ThumbnailsBox|WorkspaceThumbnail|Entry|Text|PageIndicators|Slider|Switch|Menu|Popup|ListItem|ResultsView|ProviderInfo/;

// What a click there does: 'close' (empty space of the current workspace), a Meta.Workspace to switch to (the
// neighbouring workspace previews at the sides), or null (something interactive: leave it to the shell).
function clickTarget(actor) {
    const active = global.workspace_manager.get_active_workspace();
    for (let a = actor; a; a = a.get_parent()) {
        const n = `${a.constructor?.name ?? ''} ${a.style_class ?? ''}`;
        if (INTERACTIVE.test(n))
            return null;
        const ws = a.metaWorkspace;
        if (ws && ws !== active)
            return ws;
        if (a === Main.layoutManager.overviewGroup)
            return 'close';
    }
    return null;
}

export class OverviewClose {
    enable() {
        this._press = null;
        this._id = global.stage.connect('captured-event', (_stage, event) => {
            if (!Main.overview.visible || Main.overview.animationInProgress || Main.modalCount > 1)
                return Clutter.EVENT_PROPAGATE;
            const type = event.type();
            const search = Main.overview.searchController ?? Main.overview._overview?._controls?._searchController;

            if (type === Clutter.EventType.KEY_PRESS && event.get_key_symbol() === Clutter.KEY_Escape) {
                if (search?.searchActive)
                    search.reset();
                else
                    Main.overview.hide();
                return Clutter.EVENT_STOP;
            }

            if (type === Clutter.EventType.BUTTON_PRESS && event.get_button() === Clutter.BUTTON_PRIMARY) {
                const [x, y] = event.get_coords();
                const actor = global.stage.get_actor_at_pos(Clutter.PickMode.REACTIVE, x, y);
                const target = clickTarget(actor);
                this._press = target ? [x, y, target] : null;
            } else if (type === Clutter.EventType.BUTTON_RELEASE && this._press) {
                const [x, y] = event.get_coords();
                const [px, py, target] = this._press;
                this._press = null;
                if (Math.abs(x - px) < 8 && Math.abs(y - py) < 8 && !search?.searchActive) {
                    if (target === 'close')
                        Main.overview.hide();
                    else
                        target.activate(event.get_time());   // go to that workspace, overview stays open
                    return Clutter.EVENT_STOP;
                }
            }
            return Clutter.EVENT_PROPAGATE;
        });
    }

    disable() {
        if (this._id)
            global.stage.disconnect(this._id);
        this._id = 0;
        this._press = null;
    }
}
