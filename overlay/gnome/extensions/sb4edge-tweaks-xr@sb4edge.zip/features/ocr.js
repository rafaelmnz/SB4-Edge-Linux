// Text recognition (OCR): derived from Tesseract OCR (https://github.com/Taygun86/gnome-tesseract-ocr, GPL-3.0).
// Adds an "Extract Text" mode to the screenshot UI (button or T) and a shortcut that opens it; the selection is
// captured to memory, run through tesseract, and the text copied to the clipboard.
import Gio from 'gi://Gio';
import GLib from 'gi://GLib';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import St from 'gi://St';
import Clutter from 'gi://Clutter';
import { InjectionManager, gettext as _ } from 'resource:///org/gnome/shell/extensions/extension.js';
import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import { Tooltip } from 'resource:///org/gnome/shell/ui/screenshot.js';

Gio._promisify(Shell.Screenshot, 'composite_to_stream');
Gio._promisify(Gio.Subprocess.prototype, 'communicate_utf8_async');
Gio._promisify(Gio.File.prototype, 'replace_contents_bytes_async', 'replace_contents_finish');

const UUID = 'sb4edge-tweaks-xr@sb4edge';

export class TextRecognition {
    constructor(_extension, settings) {
        this._settings = settings;
    }

    enable() {
        this._ocrCancellable = null;
        this._injections = new InjectionManager();
        this._ui = Main.screenshotUI;
        this._ocrMode = false;
        this._updatingModes = false;

        this._addButton();
        this._patchCapture();

        this._ui.connectObject(
            'closed', () => {
                if (this._ocrMode)
                    this._setMode('shot');
            },
            'key-press-event', this._onKeyPress.bind(this),
            this);

        Main.wm.addKeybinding('ocr-shortcut', this._settings,
            Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
            Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW,
            () => this._openInOcrMode());
    }

    disable() {
        Main.wm.removeKeybinding('ocr-shortcut');

        this._ocrCancellable?.cancel();
        this._ocrCancellable = null;

        this._injections.clear();
        this._injections = null;

        const ui = this._ui;
        ui.disconnectObject(this);
        ui._shotButton.disconnectObject(this);
        ui._castButton.disconnectObject(this);
        ui._selectionButton.disconnectObject(this);
        ui._screenButton.disconnectObject(this);
        ui._windowButton.disconnectObject(this);
        ui._shotButton.remove_style_pseudo_class('checked');
        ui._castButton.remove_style_pseudo_class('checked');
        ui._panel.set_style(this._oldPanelStyle);
        ui._shotCastContainer.set_style(this._oldContainerStyle);

        this._tooltip?.destroy();
        this._tooltip = null;
        this._ocrButton?.destroy();
        this._ocrButton = null;

        this._ui = null;
    }

    _addButton() {
        const ui = this._ui;

        // Make room for a third button next to screenshot / screencast.
        this._oldPanelStyle = ui._panel.get_style();
        this._oldContainerStyle = ui._shotCastContainer.get_style();
        ui._panel.set_style('padding: 10px; min-width: 0px; width: 330px;');
        ui._shotCastContainer.set_style('spacing: 2px;');

        this._ocrButton = new St.Button({
            style_class: 'screenshot-ui-shot-cast-button',
            child: new St.Icon({
                // edit-select-text is missing from Adwaita and Yaru; fall back to a common one.
                gicon: Gio.ThemedIcon.new_from_names([
                    'edit-select-text-symbolic',
                    'format-text-plaintext-symbolic',
                    'text-x-generic-symbolic',
                ]),
            }),
            x_align: Clutter.ActorAlign.START,
            y_align: Clutter.ActorAlign.CENTER,
            toggle_mode: true,
        });
        ui._shotCastContainer.add_child(this._ocrButton);

        this._tooltip = new Tooltip(this._ocrButton, {
            text: _('Extract Text (T)'),
            style_class: 'screenshot-ui-tooltip',
            visible: false,
        });
        ui.add_child(this._tooltip);

        this._ocrButton.connectObject('clicked', () => this._setMode('ocr'), this);
        ui._shotButton.connectObject(
            'clicked', () => this._setMode('shot'),
            'notify::checked', () => this._updateVisuals(),
            this);
        ui._castButton.connectObject(
            'clicked', () => this._setMode('cast'),
            'notify::checked', () => this._updateVisuals(),
            'notify::visible', () => this._updateVisuals(),
            this);
        for (const b of [ui._selectionButton, ui._screenButton, ui._windowButton])
            b.connectObject('notify::checked', () => this._updateVisuals(), this);

        this._updateVisuals();
    }

    _setMode(mode) {
        const ui = this._ui;
        if (this._updatingModes || !ui)
            return;
        this._updatingModes = true;

        this._ocrMode = mode === 'ocr';
        if (mode === 'cast') {
            ui._castButton.checked = true;
        } else {
            // OCR rides on screenshot mode so GNOME keeps the screenshot UI state.
            ui._shotButton.checked = true;
        }
        this._ocrButton.checked = this._ocrMode;

        this._updatingModes = false;
        this._updateVisuals();
    }

    _updateVisuals() {
        const ui = this._ui;
        if (!ui || !this._ocrButton)
            return;

        if (ui._castButton.checked && this._ocrMode) {
            this._ocrMode = false;
            this._ocrButton.checked = false;
        }

        const pairs = [
            [this._ocrButton, this._ocrMode],
            [ui._shotButton, !this._ocrMode && ui._shotButton.checked],
            [ui._castButton, !this._ocrMode && ui._castButton.checked],
        ];
        for (const [button, on] of pairs) {
            if (on)
                button.add_style_pseudo_class('checked');
            else
                button.remove_style_pseudo_class('checked');
        }
    }

    _onKeyPress(_actor, event) {
        const sym = event.get_key_symbol();
        const mods = event.get_state() & (Clutter.ModifierType.CONTROL_MASK |
            Clutter.ModifierType.MOD1_MASK | Clutter.ModifierType.SUPER_MASK);
        if ((sym === Clutter.KEY_t || sym === Clutter.KEY_T) && !mods) {
            this._setMode(this._ocrMode ? 'shot' : 'ocr');
            return Clutter.EVENT_STOP;
        }
        return Clutter.EVENT_PROPAGATE;
    }

    async _openInOcrMode() {
        try {
            await this._ui.open();
            if (this._ui.visible)
                this._setMode('ocr');
        } catch (e) {
            console.error(`[${UUID}] Could not open the screenshot UI: ${e.message}`);
        }
    }

    _patchCapture() {
        const ext = this;
        this._injections.overrideMethod(this._ui, '_onCaptureButtonClicked', original => {
            return async function () {
                if (!ext._ocrMode || !this._shotButton.checked)
                    return original.call(this);

                // Capture straight to memory: no file in ~/Pictures/Screenshots, no
                // "Screenshot Captured" notification, no image on the clipboard.
                let png = null;
                try {
                    png = await ext._captureSelection();
                } catch (e) {
                    console.error(`[${UUID}] Capture failed: ${e.message}`);
                }
                this.close();
                if (png)
                    await ext._runTesseract(png);
                return undefined;
            };
        });
    }

    async _captureSelection() {
        const ui = this._ui;
        let texture, geometry, scale;

        if (ui._selectionButton.checked || ui._screenButton.checked) {
            const content = ui._stageScreenshot.get_content();
            if (!content)
                return null;
            texture = content.get_texture();
            geometry = ui._getSelectedGeometry(true);
            scale = ui._scale;
        } else if (ui._windowButton.checked) {
            const win = ui._windowSelectors.flatMap(s => s.windows()).find(w => w.checked);
            if (!win?.windowContent)
                return null;
            texture = win.windowContent.get_texture();
            geometry = null;
            scale = win.bufferScale;
        } else {
            return null;
        }

        const [x, y, w, h] = geometry ?? [0, 0, -1, -1];
        const stream = Gio.MemoryOutputStream.new_resizable();
        await Shell.Screenshot.composite_to_stream(
            texture, x, y, w, h, scale, null, 0, 0, 1, stream);
        stream.close(null);
        return stream.steal_as_bytes();
    }

    async _getInstalledLangs() {
        let settings = this._settings;
        let userVal = settings.get_user_value('languages');

        if (userVal !== null) {
            return settings.get_string('languages');
        }

        // Fallback options if no settings saved yet:
        try {
            let proc = Gio.Subprocess.new(['tesseract', '--list-langs'],
                Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE);
            let [stdout] = await proc.communicate_utf8_async(null, null);

            let langs = stdout.trim().split('\n').slice(1)
                .map(l => l.trim())
                .filter(l => l && l !== 'osd');

            let engIndex = langs.indexOf('eng');
            if (engIndex !== -1) {
                langs.splice(engIndex, 1);
                langs.push('eng');
            }

            return langs.join('+');
        } catch (e) {
            console.error(`[${UUID}] Failed to get langs: ${e.message}`);
        }
        return 'eng';
    }

    async _runTesseract(png) {
        if (!GLib.find_program_in_path('tesseract')) {
            Main.notifyError(_('Tesseract OCR'),
                _('Tesseract is not installed. Install it with: sudo apt install tesseract-ocr'));
            return;
        }

        this._ocrCancellable?.cancel();
        const cancellable = new Gio.Cancellable();
        this._ocrCancellable = cancellable;

        const tmp = Gio.File.new_for_path(GLib.build_filenamev([
            GLib.get_user_runtime_dir(), `tesseract-ocr-${GLib.get_monotonic_time()}.png`]));

        try {
            await tmp.replace_contents_bytes_async(png, null, false,
                Gio.FileCreateFlags.PRIVATE | Gio.FileCreateFlags.REPLACE_DESTINATION, cancellable);

            let argv = ['tesseract', tmp.get_path(), 'stdout'];
            let allLangs = await this._getInstalledLangs();
            if (allLangs)
                argv.push('-l', allLangs);

            let proc = Gio.Subprocess.new(argv,
                Gio.SubprocessFlags.STDOUT_PIPE | Gio.SubprocessFlags.STDERR_PIPE);
            let [stdout, stderr] = await proc.communicate_utf8_async(null, cancellable);
            if (!proc.get_successful())
                throw new Error(stderr?.trim() || 'tesseract failed');

            let text = (stdout ?? '').replace(/\f/g, '').replace(/[ \t]+$/gm, '')
                .replace(/\n{3,}/g, '\n\n').trim();
            if (!text) {
                Main.notify(_('Tesseract OCR'), _('No text found in the selection.'));
                return;
            }

            St.Clipboard.get_default().set_text(St.ClipboardType.CLIPBOARD, text);
            let preview = text.length > 200 ? `${text.slice(0, 200)}…` : text;
            Main.notify(_('Text copied to clipboard'), preview);
        } catch (e) {
            if (!e.matches?.(Gio.IOErrorEnum, Gio.IOErrorEnum.CANCELLED)) {
                console.error(`[${UUID}] Tesseract failed: ${e.message}`);
                Main.notifyError(_('Tesseract OCR'), e.message);
            }
        } finally {
            tmp.delete_async(GLib.PRIORITY_DEFAULT, null, null);
            if (this._ocrCancellable === cancellable)
                this._ocrCancellable = null;
        }
    }
}
