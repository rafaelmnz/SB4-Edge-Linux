# Book 4 Edge Tweaks XR

SB4-Edge-Linux's GNOME Shell tweaks in one extension (GNOME Shell 49-51). Every feature can be switched off in
the preferences (Extensions app → Book 4 Edge Tweaks XR → Features) or with
`gsettings --schemadir <dir>/schemas set org.gnome.shell.extensions.sb4edge-tweaks-xr feature-<name> false`.

| Feature (`feature-…`) | What it does | Replaces |
|---|---|---|
| `screenshot` | Empty initial selection, capture on release, window capture on click, desktop hidden in window mode, always opens in area mode, optional mute of only the capture sound | no-screenshot-box-xr@sb4edge |
| `ocr` | "Extract Text" mode in the screenshot UI (button or T) and Shift+Super+T; copies the recognized text, no file or notification image. Needs `tesseract-ocr` | tesseract-ocr-xr@sb4edge |
| `overview` | Esc (clearing a search first) and a click on empty space close the overview and app grid; a click on a neighbouring workspace switches to it | sb4edge-overview-close@sb4edge |
| `panels` | When an extra top bar of a multi-monitor extension (Hide Top Bar (Multi-Monitor)) is destroyed, disconnects what GNOME's own top bar items (date menu, Bluetooth, Thunderbolt, background apps, ...) left connected to session-wide objects; they caused "already disposed" errors at unlock and grew with every monitor change | (new) |
| `accessibility` | The accessibility menu shows only when "Always Show Accessibility Menu" is on, on every top bar including the extra ones, also after unlock | hideaccessibilitymenu@boni.scot |
| `rustdesk` | D-Bus `/org/sb4edge/RustDeskWindow` (`org.sb4edge.RustDeskWindow.Get`): where the RustDesk remote window is, for rustdesk-display-client | rustdesk-window@sb4edge |

A feature that fails to start (e.g. after a GNOME change) is logged and skipped; the others keep working.

## Credits and licence

GPL-3.0-or-later. The screenshot feature is derived from
[No Screenshot Box](https://github.com/abdallah-alkanani/no-screenshot-box) by abdallah-alkanani (GPL-3.0) and the
text recognition feature from [Tesseract OCR](https://github.com/Taygun86/gnome-tesseract-ocr) by Taygun86
(GPL-3.0); the other features were written for SB4-Edge-Linux.
