// Book 4 Edge Tweaks: SB4-Edge-Linux's GNOME Shell tweaks in one extension.
// Each feature lives in features/<name>.js, exports a class with enable()/disable(), and is switched on and off
// at runtime by the boolean key feature-<name> in the extension's settings.
// GPL-3.0-or-later (the screenshot and OCR features are derived from GPL-3.0 extensions; see README.md).
import {Extension} from 'resource:///org/gnome/shell/extensions/extension.js';

import {ScreenshotTweaks} from './features/screenshot.js';
import {TextRecognition} from './features/ocr.js';
import {OverviewClose} from './features/overview.js';
import {RustDeskWindow} from './features/rustdesk.js';
import {PanelCleanup} from './features/panelCleanup.js';
import {AccessibilityMenu} from './features/accessibility.js';
import {KeyboardStatus} from './features/keyboard.js';

// Enable order matters only for the screenshot UI: both screenshot features patch it, and each restores its own
// patches in disable(), which runs in the reverse order.
const FEATURES = [
    ['screenshot', ScreenshotTweaks],
    ['ocr', TextRecognition],
    ['overview', OverviewClose],
    ['rustdesk', RustDeskWindow],
    ['panels', PanelCleanup],
    ['accessibility', AccessibilityMenu],
    ['keyboard', KeyboardStatus],
];

export default class Book4EdgeTweaks extends Extension {
    enable() {
        this._settings = this.getSettings();
        this._active = new Map();
        for (const [name, Feature] of FEATURES) {
            this._settings.connectObject(`changed::feature-${name}`, () => this._sync(name, Feature), this);
            this._sync(name, Feature);
        }
    }

    disable() {
        this._settings.disconnectObject(this);
        for (const [name] of [...FEATURES].reverse())
            this._stop(name);
        this._active = null;
        this._settings = null;
    }

    _sync(name, Feature) {
        const wanted = this._settings.get_boolean(`feature-${name}`);
        if (wanted && !this._active.has(name)) {
            const feature = new Feature(this, this._settings);
            try {
                feature.enable();
                this._active.set(name, feature);
            } catch (e) {
                // One broken feature (e.g. after a GNOME change) must not take the others down.
                console.error(`[${this.uuid}] feature ${name} failed to start: ${e.message}\n${e.stack}`);
                try {
                    feature.disable();
                } catch {}
            }
        } else if (!wanted) {
            this._stop(name);
        }
    }

    _stop(name) {
        const feature = this._active.get(name);
        if (!feature)
            return;
        this._active.delete(name);
        try {
            feature.disable();
        } catch (e) {
            console.error(`[${this.uuid}] feature ${name} failed to stop: ${e.message}`);
        }
    }
}
