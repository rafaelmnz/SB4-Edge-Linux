// Preferences for Book 4 Edge Tweaks XR: a Features page with one switch per feature, plus the screenshot and text
// recognition options (from No Screenshot Box and Tesseract OCR, GPL-3.0).
import Gio from 'gi://Gio';
import Gdk from 'gi://Gdk';
import Gtk from 'gi://Gtk';
import Adw from 'gi://Adw';
import GLib from 'gi://GLib';
import { ExtensionPreferences, gettext as _ } from 'resource:///org/gnome/Shell/Extensions/js/extensions/prefs.js';

const FEATURES = [
    ['feature-screenshot', 'Screenshot', 'Empty initial selection, capture on release, window capture on click, no desktop in window mode, optional mute.'],
    ['feature-ocr', 'Text recognition (OCR)', 'An "Extract Text" mode in the screenshot UI (T) and a shortcut; copies the text. Needs tesseract-ocr.'],
    ['feature-overview', 'Overview', 'Esc and a click on empty space close the overview and app grid; a click on a neighbouring workspace switches to it.'],
    ['feature-rustdesk', 'RustDesk window locator', 'Tells rustdesk-display-client which monitor the RustDesk remote window is on.'],
    ['feature-panels', 'Extra top bar cleanup', 'When an extra top bar (Hide Top Bar on other monitors) is destroyed, removes what GNOME leaves connected (errors at unlock, wasted work).'],
    ['feature-accessibility', 'Accessibility menu', 'Shown on every top bar only when "Always Show Accessibility Menu" is on, even with Large Text active.'],
];

const SCREENSHOT = [
    ['remove-preselected-box', 'Remove preselected box', "Start with an empty selection instead of GNOME's preselected area."],
    ['screenshot-on-release', 'Screenshot on release', 'Capture the selected area when the drag ends.'],
    ['start-in-area-mode', 'Always start in area mode', 'Open dimmed with the area selector instead of the last used mode.'],
    ['capture-window-on-click', 'Capture window on click', 'In window mode, capture a window as soon as it is clicked.'],
    ['hide-desktop-window', 'Hide the desktop in window mode', 'Do not offer the desktop (Desktop Icons NG) as a window to capture.'],
    ['mute-screenshot-sound', 'Mute screenshot sound', 'Mute only the screenshot sound, not other system or application audio.'],
];

export default class Book4EdgeTweaksPreferences extends ExtensionPreferences {
    fillPreferencesWindow(window) {
        const settings = this.getSettings();
        window.search_enabled = true;
        window.add(this._switchPage(_('Features'), 'emblem-system-symbolic', _('Features'), FEATURES, settings));
        const shot = this._switchPage(_('Screenshot'), 'camera-photo-symbolic', _('Screenshot'), SCREENSHOT, settings);
        window.add(shot);
        const ocr = this._ocrPage(window, settings);
        window.add(ocr);
        const sync = () => {
            shot.sensitive = settings.get_boolean('feature-screenshot');
            ocr.sensitive = settings.get_boolean('feature-ocr');
        };
        settings.connect('changed::feature-screenshot', sync);
        settings.connect('changed::feature-ocr', sync);
        sync();
    }

    _switchPage(title, icon, groupTitle, rows, settings) {
        const page = new Adw.PreferencesPage({title, icon_name: icon});
        const group = new Adw.PreferencesGroup({title: groupTitle});
        for (const [key, rowTitle, subtitle] of rows) {
            const row = new Adw.SwitchRow({title: _(rowTitle), subtitle: _(subtitle)});
            settings.bind(key, row, 'active', Gio.SettingsBindFlags.DEFAULT);
            group.add(row);
        }
        page.add(group);
        return page;
    }

    _ocrPage(window, settings) {
        const page = new Adw.PreferencesPage({
            title: _('Text Recognition'),
            icon_name: 'edit-find-symbolic',
        });

        let wrapper;
        let shortcutGroup;

        // Get installed list
        let installedLangs = [];
        try {
            let [ok, stdout, stderr] = GLib.spawn_command_line_sync('tesseract --list-langs');
            if (ok && stdout) {
                let output = new TextDecoder().decode(stdout);
                let lines = output.split('\n');
                installedLangs = lines.slice(1)
                                      .map(l => l.trim())
                                      .filter(l => l && l !== 'osd');
            }
        } catch (e) {
            console.error(e);
        }

        let userVal = settings.get_user_value('languages');
        let savedLangsString = settings.get_string('languages');
        let selectedLangs = [];

        if (userVal !== null) {
            selectedLangs = savedLangsString ? savedLangsString.split('+') : [];
        } else {
             selectedLangs = [...installedLangs];
             let engIndex = selectedLangs.indexOf('eng');
             if (engIndex !== -1) {
                 selectedLangs.splice(engIndex, 1);
                 selectedLangs.push('eng');
             }
             settings.set_string('languages', selectedLangs.join('+'));
        }

        let currentOrder = Array.from(new Set([...selectedLangs, ...installedLangs]));
        let enabledMap = {}; 
        installedLangs.forEach(l => enabledMap[l] = false);
        selectedLangs.forEach(l => enabledMap[l] = true);

        currentOrder.sort((a,b) => {
             let aSel = selectedLangs.indexOf(a);
             let bSel = selectedLangs.indexOf(b);
             if (aSel !== -1 && bSel !== -1) return aSel - bSel;
             if (aSel !== -1) return -1;
             if (bSel !== -1) return 1;
             return a.localeCompare(b);
        });

        const renderList = () => {
            if (wrapper) {
                page.remove(wrapper);
            }
            wrapper = new Adw.PreferencesGroup({
                title: _('Tesseract OCR Languages'),
                description: _('Toggle languages and move them up/down to change priority. High priority languages will help Tesseract decide during OCR.')
            });
            page.add(wrapper);
            if (shortcutGroup) {
                page.remove(shortcutGroup);
                page.add(shortcutGroup);
            }

            currentOrder.forEach((lang, index) => {
                let row = new Adw.ActionRow({
                    title: lang,
                });

                let switchWidget = new Gtk.Switch({
                    active: enabledMap[lang] || false,
                    valign: Gtk.Align.CENTER
                });
                
                switchWidget.connect('notify::active', () => {
                    enabledMap[lang] = switchWidget.active;
                    let active = currentOrder.filter(l => enabledMap[l]);
                    settings.set_string('languages', active.join('+'));
                });

                let upBtn = new Gtk.Button({
                    icon_name: 'go-up-symbolic',
                    valign: Gtk.Align.CENTER,
                    margin_end: 5
                });
                upBtn.connect('clicked', () => {
                    if (index > 0) {
                        let tmp = currentOrder[index - 1];
                        currentOrder[index - 1] = currentOrder[index];
                        currentOrder[index] = tmp;
                        let active = currentOrder.filter(l => enabledMap[l]);
                        settings.set_string('languages', active.join('+'));
                        renderList();
                    }
                });
                if (index === 0) upBtn.sensitive = false;

                let downBtn = new Gtk.Button({
                    icon_name: 'go-down-symbolic',
                    valign: Gtk.Align.CENTER,
                    margin_end: 10
                });
                downBtn.connect('clicked', () => {
                    if (index < currentOrder.length - 1) {
                        let tmp = currentOrder[index + 1];
                        currentOrder[index + 1] = currentOrder[index];
                        currentOrder[index] = tmp;
                        let active = currentOrder.filter(l => enabledMap[l]);
                        settings.set_string('languages', active.join('+'));
                        renderList();
                    }
                });
                if (index === currentOrder.length - 1) downBtn.sensitive = false;

                let box = new Gtk.Box({ orientation: Gtk.Orientation.HORIZONTAL });
                box.append(upBtn);
                box.append(downBtn);
                row.add_suffix(box);
                row.add_suffix(switchWidget);

                wrapper.add(row);
            });
        };

        renderList();

        shortcutGroup = new Adw.PreferencesGroup({ title: _('Shortcut') });
        shortcutGroup.add(this._buildShortcutRow(window, settings));
        page.add(shortcutGroup);
        return page;
    }

    _buildShortcutRow(window, settings) {
        const row = new Adw.ActionRow({
            title: _('Open the screenshot UI in OCR mode'),
            subtitle: _('Click to set a new shortcut'),
            activatable: true,
        });
        const label = new Gtk.ShortcutLabel({
            disabled_text: _('Disabled'),
            valign: Gtk.Align.CENTER,
        });
        const sync = () => { label.accelerator = settings.get_strv('ocr-shortcut')[0] ?? ''; };
        sync();
        settings.connect('changed::ocr-shortcut', sync);
        row.add_suffix(label);
        row.connect('activated', () => this._recordShortcut(window, settings));
        return row;
    }

    // Records a key combination: Esc cancels, Backspace disables the shortcut.
    _recordShortcut(window, settings) {
        const dialog = new Adw.Dialog({
            title: _('Set Shortcut'),
            content_width: 440,
        });
        const status = new Adw.StatusPage({
            icon_name: 'preferences-desktop-keyboard-shortcuts-symbolic',
            title: _('Press the new shortcut'),
            description: _('Press Esc to cancel or Backspace to disable the shortcut.'),
        });
        const toolbar = new Adw.ToolbarView({ content: status });
        toolbar.add_top_bar(new Adw.HeaderBar({ show_end_title_buttons: false }));
        dialog.set_child(toolbar);

        const controller = new Gtk.EventControllerKey({
            propagation_phase: Gtk.PropagationPhase.CAPTURE,
        });
        controller.connect('key-pressed', (_c, keyval, keycode, state) => {
            const mods = state & Gtk.accelerator_get_default_mod_mask();
            let key = Gdk.keyval_to_lower(keyval);

            if (!mods && key === Gdk.KEY_Escape) {
                dialog.close();
                return Gdk.EVENT_STOP;
            }
            if (!mods && key === Gdk.KEY_BackSpace) {
                settings.set_strv('ocr-shortcut', []);
                dialog.close();
                return Gdk.EVENT_STOP;
            }
            // Wait for the non-modifier key.
            if (this._isModifierKey(key))
                return Gdk.EVENT_STOP;
            if (key === Gdk.KEY_ISO_Left_Tab)
                key = Gdk.KEY_Tab;

            // Like GNOME Settings: plain keys need a modifier, except F-keys and Print.
            const standalone = (key >= Gdk.KEY_F1 && key <= Gdk.KEY_F35) || key === Gdk.KEY_Print;
            if (!mods && !standalone) {
                status.description = _('Use a modifier such as Super, Ctrl or Alt. Esc cancels.');
                return Gdk.EVENT_STOP;
            }
            const accel = Gtk.accelerator_name_with_keycode(null, key, keycode, mods);
            if (!accel || !Gtk.accelerator_valid(key, mods)) {
                status.description = _('That combination cannot be used. Esc cancels.');
                return Gdk.EVENT_STOP;
            }
            settings.set_strv('ocr-shortcut', [accel]);
            dialog.close();
            return Gdk.EVENT_STOP;
        });
        dialog.add_controller(controller);
        dialog.present(window);
    }

    _isModifierKey(key) {
        return [
            Gdk.KEY_Shift_L, Gdk.KEY_Shift_R, Gdk.KEY_Control_L, Gdk.KEY_Control_R,
            Gdk.KEY_Alt_L, Gdk.KEY_Alt_R, Gdk.KEY_Meta_L, Gdk.KEY_Meta_R,
            Gdk.KEY_Super_L, Gdk.KEY_Super_R, Gdk.KEY_Hyper_L, Gdk.KEY_Hyper_R,
            Gdk.KEY_ISO_Level3_Shift, Gdk.KEY_Caps_Lock, Gdk.KEY_Num_Lock,
        ].includes(key);
    }
}
