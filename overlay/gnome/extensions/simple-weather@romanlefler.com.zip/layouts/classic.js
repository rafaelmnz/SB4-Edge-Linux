/*
    Copyright 2025 Roman Lefler

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
import Clutter from "gi://Clutter";
import St from "gi://St";
import * as Main from "resource:///org/gnome/shell/ui/main.js";
import { boxOrientation } from "../clutterutils.js";
import { detailName, Details, displayDetail } from "../details.js";
import { gettext as _g } from "../gettext.js";
import { displayTime } from "../lang.js";
import { createWeatherIcon } from "./icons.js";
function addChildren(parent, ...children) {
    children.forEach(child => parent.add_child(child));
}
function usePrimaryTextColor(config, label) {
    if (config.getTheme() !== "")
        return;
    const color = Main.panel.get_theme_node().get_foreground_color();
    label.style = `color: rgba(${color.red}, ${color.green}, ${color.blue}, ${color.alpha / 255})`;
}
function createForecastView(config) {
    const actor = new St.BoxLayout({
        ...boxOrientation(Clutter.Orientation.VERTICAL),
        x_expand: true,
        x_align: Clutter.ActorAlign.CENTER,
        style_class: "sw-classic-hourly-item"
    });
    const time = new St.Label({
        x_align: Clutter.ActorAlign.CENTER,
        style_class: "sw-classic-forecast-time"
    });
    const iconBox = new St.BoxLayout({
        x_expand: true,
        x_align: Clutter.ActorAlign.CENTER,
        style_class: "sw-classic-forecast-icon-box"
    });
    const icon = new St.Icon({
        icon_name: "view-refresh-symbolic",
        x_align: Clutter.ActorAlign.CENTER,
        style_class: "sw-classic-forecast-icon"
    });
    const temperature = new St.Label({
        y_align: Clutter.ActorAlign.CENTER,
        style_class: "sw-classic-forecast-temperature"
    });
    usePrimaryTextColor(config, temperature);
    const summary = new St.Label({
        x_align: Clutter.ActorAlign.CENTER,
        style_class: "sw-classic-forecast-summary"
    });
    summary.clutter_text.line_wrap = true;
    addChildren(iconBox, icon, temperature);
    addChildren(actor, time, iconBox, summary);
    return { actor, view: { time, icon, temperature, summary } };
}
/**
 * OpenWeather Refined's current-conditions and today's-forecast presentation.
 * SimpleWeather owns the separate footer, so location switching and actions do
 * not need to be duplicated here.
 */
export class ClassicLayout {
    actor;
    #args;
    #currentIcon;
    #location;
    #summary;
    #sunrise;
    #sunset;
    #updated;
    #detailBox;
    #detailCaptions;
    #detailValues;
    #hourly;
    constructor(args) {
        this.#args = args;
        this.actor = new St.BoxLayout({
            ...boxOrientation(Clutter.Orientation.VERTICAL),
            x_expand: true,
            style_class: "sw-classic-layout"
        });
        const currentRow = new St.BoxLayout({
            x_expand: true,
            style_class: "sw-classic-current-row"
        });
        this.#currentIcon = new St.Icon({
            icon_name: "weather-clear-symbolic",
            style_class: "sw-classic-current-icon"
        });
        currentRow.add_child(this.#currentIcon);
        const summaryBox = new St.BoxLayout({
            ...boxOrientation(Clutter.Orientation.VERTICAL),
            x_expand: true,
            y_expand: true,
            y_align: Clutter.ActorAlign.CENTER,
            style_class: "sw-classic-summary-box"
        });
        this.#location = new St.Label({ style_class: "sw-classic-location" });
        this.#summary = new St.Label({ style_class: "sw-classic-summary" });
        usePrimaryTextColor(args.config, this.#summary);
        const sunInfo = new St.BoxLayout({ style_class: "sw-classic-sun-info" });
        const sunriseIcon = new St.Icon({
            icon_name: "daytime-sunrise-symbolic",
            style_class: "sw-classic-sun-icon sw-classic-first-sun-icon"
        });
        this.#sunrise = new St.Label();
        const sunsetIcon = new St.Icon({
            icon_name: "daytime-sunset-symbolic",
            style_class: "sw-classic-sun-icon"
        });
        this.#sunset = new St.Label();
        const updatedIcon = new St.Icon({
            icon_name: "view-refresh-symbolic",
            style_class: "sw-classic-update-icon"
        });
        this.#updated = new St.Label();
        addChildren(sunInfo, sunriseIcon, this.#sunrise, sunsetIcon, this.#sunset, updatedIcon, this.#updated);
        addChildren(summaryBox, this.#location, this.#summary, sunInfo);
        currentRow.add_child(summaryBox);
        this.#detailBox = new St.BoxLayout({
            x_expand: false,
            y_align: Clutter.ActorAlign.CENTER,
            style_class: "sw-classic-detail-box"
        });
        const captions = new St.BoxLayout({
            ...boxOrientation(Clutter.Orientation.VERTICAL),
            style_class: "sw-classic-detail-captions"
        });
        const values = new St.BoxLayout({
            ...boxOrientation(Clutter.Orientation.VERTICAL),
            style_class: "sw-classic-detail-values"
        });
        this.#detailCaptions = [];
        this.#detailValues = Array.from({ length: Object.values(Details).length }, () => {
            const caption = new St.Label();
            captions.add_child(caption);
            this.#detailCaptions.push(caption);
            const value = new St.Label({ text: "\u2026" });
            usePrimaryTextColor(args.config, value);
            values.add_child(value);
            return value;
        });
        addChildren(this.#detailBox, captions, values);
        this.#setDetailCount(args.config.getClassicDetailsList().length);
        currentRow.add_child(this.#detailBox);
        this.actor.add_child(currentRow);
        const hourlyRow = new St.BoxLayout({
            x_expand: true,
            style_class: "sw-classic-hourly-row"
        });
        this.#hourly = [];
        for (let index = 0; index < 4; index++) {
            const forecast = createForecastView(args.config);
            hourlyRow.add_child(forecast.actor);
            this.#hourly.push(forecast.view);
        }
        this.actor.add_child(hourlyRow);
    }
    updateGui(weather) {
        const { config, metadata } = this.#args;
        this.#currentIcon.gicon = createWeatherIcon(metadata, weather.gIconName, config.getAlwaysPackagedIcons());
        this.#location.text = weather.loc.getName();
        this.#summary.text = `${weather.conditionText.display(config)}, ${weather.temp.display(config)}`;
        this.#sunrise.text = displayTime(weather.sunrise, config);
        this.#sunset.text = displayTime(weather.sunset, config);
        this.#updated.text = displayTime(weather.observedAt, config);
        const details = config.getClassicDetailsList();
        this.#setDetailCount(details.length);
        this.#detailCaptions.forEach((caption, index) => {
            if (index >= details.length)
                return;
            const rawDetail = details[index];
            const detail = rawDetail;
            if (!Object.values(Details).includes(detail)) {
                caption.text = `${_g("Invalid")}:`;
                this.#detailValues[index].text = "";
                return;
            }
            caption.text = `${_g(detailName[detail])}:`;
            this.#detailValues[index].text = displayDetail(weather, detail, _g, config, true);
        });
        const hourly = weather.hourForecast
            .filter((_, index) => index % 3 === 0)
            .slice(0, this.#hourly.length);
        this.#updateForecastViews(this.#hourly, hourly, forecast => displayTime(forecast.date, config, true));
    }
    destroy() {
        this.actor.destroy();
    }
    #setDetailCount(count) {
        this.#detailBox.visible = count > 0;
        this.#detailCaptions.forEach((caption, index) => {
            const visible = index < count;
            caption.visible = visible;
            this.#detailValues[index].visible = visible;
        });
    }
    #updateForecastViews(views, forecasts, timeText) {
        views.forEach((view, index) => {
            const forecast = forecasts[index];
            if (!forecast) {
                view.time.text = "";
                view.icon.icon_name = "";
                view.temperature.text = "";
                view.summary.text = "";
                return;
            }
            view.time.text = timeText(forecast);
            view.icon.gicon = createWeatherIcon(this.#args.metadata, forecast.gIconName, this.#args.config.getAlwaysPackagedIcons());
            if (forecast.temp !== undefined) {
                view.temperature.text = forecast.temp.display(this.#args.config);
            }
            else if (forecast.tempMax !== undefined && forecast.tempMin !== undefined) {
                view.temperature.text = `${forecast.tempMax.display(this.#args.config)} / ${forecast.tempMin.display(this.#args.config)}`;
            }
            else {
                view.temperature.text = "";
            }
            view.summary.text = forecast.conditionText?.display(this.#args.config) ?? "";
        });
    }
}
