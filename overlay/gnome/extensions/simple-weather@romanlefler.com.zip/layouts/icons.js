/*
    Copyright 2025 Roman Lefler

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
*/
import { getWeatherGIcon } from "../icons.js";
export function createWeatherIcon(metadata, name, packaged = false) {
    return getWeatherGIcon(name, metadata.path, { packaged });
}
