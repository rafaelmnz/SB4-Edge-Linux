/*
    Copyright 2025 Roman Lefler

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
import { OpenMeteo } from "./openmeteo.js";
import { OPENWEATHERMAP3_API_KEY, OPENWEATHERMAP3_NAME, OpenWeatherMap3 } from "./openweathermap3.js";
import { QWeather } from "./qweather.js";
export function createProvider(soup, config) {
    const id = config.getWeatherProvider();
    switch (id) {
        case 1:
            return new OpenMeteo(soup, config);
        case 2:
            return new OpenWeatherMap3(soup, config);
        case 3:
            return new QWeather(soup, config);
        default:
            throw new Error("Invalid weather provider ID.");
    }
}
export const WeatherProviderKeys = Object.freeze([
    "Open-Meteo", OPENWEATHERMAP3_NAME, "QWeather"
]);
/**
 * Keys used by the api-keys setting.
 */
export const WeatherProviderApiKeys = Object.freeze([
    "Open-Meteo", OPENWEATHERMAP3_API_KEY, "QWeather"
]);
export function provRequiresKey(index) {
    const v = {
        0: false,
        1: true,
        2: true
    };
    const ret = v[index];
    if (typeof ret !== "boolean")
        throw new Error("Invalid argument.");
    return ret;
}
export function provRequiresHost(index) {
    const v = {
        0: false,
        1: false,
        2: true
    };
    const ret = v[index];
    if (typeof ret !== "boolean")
        throw new Error("Invalid argument.");
    return ret;
}
